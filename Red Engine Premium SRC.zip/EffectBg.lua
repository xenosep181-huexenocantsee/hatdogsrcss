import "android.graphics.*"
import "android.os.*"
import "android.graphics.drawable.GradientDrawable"

-- ===============================
-- SIZE
-- ===============================
local w = 500
local h = 330

local bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
local canvas = Canvas(bmp)

function SetAuraOutline(view, InsideColor, radius, AuraColor)
  local drawable = GradientDrawable()
  drawable.setShape(GradientDrawable.RECTANGLE)
  drawable.setCornerRadii({
    radius, radius,
    radius, radius,
    radius, radius,
    radius, radius
  })
  drawable.setColor(InsideColor)
  drawable.setStroke(2, AuraColor)
  view.setBackgroundDrawable(drawable)
  view.setLayerType(View.LAYER_TYPE_SOFTWARE, nil)
end

SetAuraOutline(
  particleView,
  0xFF13112A,
  12,
  0xFFFF3B3B
)

-- ===============================
-- RANDOM NETWORK SETTINGS
-- ===============================
math.randomseed(os.time())

local NET_COUNT = math.random(12, 20)
local MAX_DIST = math.random(50, 90)
local net = {}

local function randomNode()
  return {
    x = math.random() * w,
    y = math.random() * h,
    vx = (math.random() * 2 - 1) * math.random() * 1.8,
    vy = (math.random() * 2 - 1) * math.random() * 1.8,
    r  = math.random(2, 4)
  }
end

for i = 1, NET_COUNT do
  net[i] = randomNode()
end

-- ===============================
-- PAINTS
-- ===============================
local dotPaint = Paint()
dotPaint.setAntiAlias(true)

local glowPaint = Paint()
glowPaint.setAntiAlias(true)
glowPaint.setStyle(Paint.Style.STROKE)
glowPaint.setStrokeWidth(4)
glowPaint.setColor(0xFFFF3B3B)
glowPaint.setMaskFilter(BlurMaskFilter(8, BlurMaskFilter.Blur.NORMAL))

local linePaint = Paint()
linePaint.setAntiAlias(true)
linePaint.setStrokeWidth(1)
linePaint.setColor(0xFFFFFFFF)

-- ===============================
-- DRAW NETWORK
-- ===============================
local function drawNetwork()
  canvas.drawColor(0xFF13112A)

  for i, p in ipairs(net) do
    -- Movement
    p.x = p.x + p.vx + math.random(-1,1) * 0.05
    p.y = p.y + p.vy + math.random(-1,1) * 0.05

    -- Bounce
    if p.x < 0 or p.x > w then p.vx = -p.vx end
    if p.y < 0 or p.y > h then p.vy = -p.vy end

    -- Random respawn (rare)
    if math.random() < 0.002 then
      net[i] = randomNode()
    end
  end

  -- Connections
  for i = 1, #net do
    for j = i + 1, #net do
      local a, b = net[i], net[j]
      local dx = a.x - b.x
      local dy = a.y - b.y
      local d = math.sqrt(dx*dx + dy*dy)

      if d < MAX_DIST then
        local alpha = (1 - d / MAX_DIST) * 400

        glowPaint.setAlpha(alpha * 0.7)
        canvas.drawLine(a.x, a.y, b.x, b.y, glowPaint)

        linePaint.setAlpha(alpha)
        canvas.drawLine(a.x, a.y, b.x, b.y, linePaint)
      end
    end
  end

  -- Dots
  for _, p in ipairs(net) do
    dotPaint.setColor(0xFFFFFFFF)
    canvas.drawCircle(p.x, p.y, p.r, dotPaint)
  end
end

-- ===============================
-- RENDER LOOP
-- ===============================
local function draw()
  drawNetwork()
  particleView.setImageBitmap(bmp)
end

local handler = Handler()
local run

run = Runnable{
  run = function()
    draw()
    handler.postDelayed(run, 16)
  end
}

handler.post(run)


