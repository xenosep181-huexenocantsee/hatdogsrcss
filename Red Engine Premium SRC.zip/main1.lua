require "import"
import "res/init"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "android.content.*"
import "android.graphics.Typeface"
import "android.graphics.Paint"
import "android.net.*"
import "android.provider.Settings"
import "android.content.Context"
import "android.view.animation.*"
import "android.content.pm.ActivityInfo"
import "AndLua"
import "http"
import "layout"
import "java.io.File"
import "android.net.Uri"
import "fpsmeter"
import "drawable"
import "android.graphics.drawable.StateListDrawable"
import "android.widget.Toast"
import "android.view.Gravity"
import "android.graphics.drawable.GradientDrawable"
import "android.graphics.drawable.Drawable"

activity.setTheme(R.AndLua1)
activity.setContentView(loadlayout(layout))
activity.actionBar.hide()
activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS).setStatusBarColor(0xFF000000);


cyberAccent = 0xFFFFFFFF
cyberPurple = 0xFFAA00FF
cyberCyan = 0xFF00D9FF

-- Current sub-tab for SKINS
currentSkinsSubTab = "basic"
currentMemorySubTab = "ability"


layout2 = {
  LinearLayout;
  layout_height = "wrap";
  layout_width = "wrap";
  {
    CardView;
    layout_height = "wrap";
    layout_width = "wrap";
    backgroundColor = "0xFF000000";
    cardElevation = "12dp";
    radius = "5dp";
    id = "menu";
    {
      LinearLayout;
      layout_height = "wrap";
      layout_width = "wrap";
      Orientation = "vertical";
      {
        LinearLayout;
        Orientation = "horizontal";
        layout_height = "45dp";
        layout_width = "370dp";
        backgroundColor = "0xFF000000";
        gravity = "center_vertical";
        paddingLeft = "20dp";
        paddingRight = "20dp";
        {
          TextView;
          text = "R-ENGINE PREM";
          textSize = "40sp";
          textColor = "0xFFFFFFFF";
          Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
          layout_width = "0dp";
          layout_weight = "1";
          layout_height = "wrap";
          id = "tit1";
        };
        {
          CardView;
          layout_width = "44dp";
          layout_height = "44dp";
          radius = "8dp";
          cardElevation = "4dp";
          backgroundColor = "0x00000000";
          id="cardex";
          {
            ImageView;
            layout_width = "40dp";
            layout_height = "40dp";
            src = "img/ex.png";
            id = "eximg";
            colorFilter = "0xFF888888";
            layout_gravity = "center";
            layout_marginLeft = "5dp";
          };
        };
      };

      {
        View;
        layout_width = "fill";
        layout_height = "1dp";
        backgroundColor = "0xFF2B2B2B";
      };
      {
        LinearLayout;
        Orientation = "horizontal";
        layout_height = "300dp";
        layout_width = "370dp";
        backgroundColor = "0xFF000000";
        id = "cheatMenu";
        {
          LinearLayout;
          Orientation = "vertical";
          layout_height = "fill";
          layout_width = "150dp";
          backgroundColor = "0xFF000000";
          id = "tablin";
          paddingTop = "0dp";

          -- TAB 1: Visuals
          {
            CardView;
            layout_width = "fill";
            layout_height = "35dp";
            backgroundColor = "0xFF00C9A7";
            cardElevation = "0dp";
            radius = "0dp";
            id = "tab1";
            layout_marginBottom = "0dp";
            {
              LinearLayout;
              orientation = "horizontal";
              layout_width = "fill";
              layout_height = "fill";
              {
                View;
                layout_width = "3dp";
                layout_height = "fill";
                id = "tab1Indicator";
              };
              {
                LinearLayout;
                orientation = "horizontal";
                layout_width = "fill";
                layout_height = "fill";
                gravity = "center_vertical";
                paddingLeft = "15dp";
                {
                  ImageView;
                  layout_width = "24dp";
                  layout_height = "24dp";
                  src = "img/Visuals.png";
                  id = "tab1icon";
                  colorFilter = "0xFFFFFFFF";
                };
                {
                  TextView;
                  text = "Visuals";
                  textSize = "14sp";
                  textColor = "0xFFFFFFFF";
                  Typeface = Typeface.defaultFromStyle(Typeface.NORMAL);
                  layout_width = "wrap";
                  layout_height = "wrap";
                  layout_marginLeft = "12dp";
                  id = "tab1text";
                };
              };
            };
          };

          -- TAB 2: Aimbot
          {
            CardView;
            layout_width = "fill";
            layout_height = "35dp";
            backgroundColor = "0xFF000000";
            cardElevation = "0dp";
            radius = "0dp";
            id = "tab2";
            layout_marginBottom = "0dp";
            {
              LinearLayout;
              orientation = "horizontal";
              layout_width = "fill";
              layout_height = "fill";

              {
                View;
                layout_width = "3dp";
                layout_height = "fill";
                id = "tab2Indicator";
              };

              {
                LinearLayout;
                orientation = "horizontal";
                layout_width = "fill";
                layout_height = "fill";
                gravity = "center_vertical";
                paddingLeft = "15dp";
                {
                  ImageView;
                  layout_width = "24dp";
                  layout_height = "24dp";
                  src = "img/Aimbot.png";
                  id = "tab2icon";
                  colorFilter = "0xFFFFFFFF";
                };
                {
                  TextView;
                  text = "Aimbot";
                  textSize = "14sp";
                  textColor = "0xFF8A9AB0";
                  Typeface = Typeface.defaultFromStyle(Typeface.NORMAL);
                  layout_width = "wrap";
                  layout_height = "wrap";
                  layout_marginLeft = "12dp";
                  id = "tab2text";
                };
              };
            };
          };

          -- TAB 3: Memory
          {
            CardView;
            layout_width = "fill";
            layout_height = "35dp";
            backgroundColor = "0xFF000000";
            cardElevation = "0dp";
            radius = "0dp";
            id = "tab3";
            layout_marginBottom = "0dp";
            {
              LinearLayout;
              orientation = "horizontal";
              layout_width = "fill";
              layout_height = "fill";

              {
                View;
                layout_width = "3dp";
                layout_height = "fill";
                id = "tab3Indicator";
              };

              {
                LinearLayout;
                orientation = "horizontal";
                layout_width = "fill";
                layout_height = "fill";
                gravity = "center_vertical";
                paddingLeft = "15dp";
                {
                  ImageView;
                  layout_width = "24dp";
                  layout_height = "24dp";
                  src = "img/Memory.png";
                  id = "tab3icon";
                };
                {
                  TextView;
                  text = "Memory";
                  textSize = "14sp";
                  textColor = "0xFF8A9AB0";
                  Typeface = Typeface.defaultFromStyle(Typeface.NORMAL);
                  layout_width = "wrap";
                  layout_height = "wrap";
                  layout_marginLeft = "12dp";
                  id = "tab3text";
                  colorFilter = "0xFFFFFFFF";
                };
              };
            };
          };

          -- TAB 4: Miscellaneous
          {
            CardView;
            layout_width = "fill";
            layout_height = "35dp";
            backgroundColor = "0xFF000000";
            cardElevation = "0dp";
            radius = "0dp";
            id = "tab4";
            layout_marginBottom = "0dp";
            {
              LinearLayout;
              orientation = "horizontal";
              layout_width = "fill";
              layout_height = "fill";

              {
                View;
                layout_width = "3dp";
                layout_height = "fill";
                id = "tab4Indicator";
              };

              {
                LinearLayout;
                orientation = "horizontal";
                layout_width = "fill";
                layout_height = "fill";
                gravity = "center_vertical";
                paddingLeft = "15dp";
                {
                  ImageView;
                  layout_width = "24dp";
                  layout_height = "24dp";
                  src = "img/Misc.png";
                  id = "tab4icon";
                };
                {
                  TextView;
                  text = "Miscellaneous";
                  textSize = "14sp";
                  textColor = "0xFF8A9AB0";
                  Typeface = Typeface.defaultFromStyle(Typeface.NORMAL);
                  layout_width = "wrap";
                  layout_height = "wrap";
                  layout_marginLeft = "12dp";
                  id = "tab4text";
                  colorFilter = "0xFFFFFFFF";
                };
              };
            };
          };

          -- TAB 5: Skins
          {
            CardView;
            layout_width = "fill";
            layout_height = "35dp";
            backgroundColor = "0xFF000000";
            cardElevation = "0dp";
            radius = "0dp";
            id = "tab5";
            layout_marginBottom = "0dp";
            {
              LinearLayout;
              orientation = "horizontal";
              layout_width = "fill";
              layout_height = "fill";

              {
                View;
                layout_width = "3dp";
                layout_height = "fill";
                id = "tab5Indicator";
              };

              {
                LinearLayout;
                orientation = "horizontal";
                layout_width = "fill";
                layout_height = "fill";
                gravity = "center_vertical";
                paddingLeft = "15dp";
                {
                  ImageView;
                  layout_width = "24dp";
                  layout_height = "24dp";
                  src = "img/Skins.png";
                  id = "tab5icon";
                  colorFilter = "0xFFFFFFFF";
                };
                {
                  TextView;
                  text = "Skins";
                  textSize = "14sp";
                  textColor = "0xFF8A9AB0";
                  Typeface = Typeface.defaultFromStyle(Typeface.NORMAL);
                  layout_width = "wrap";
                  layout_height = "wrap";
                  layout_marginLeft = "12dp";
                  id = "tab5text";
                };
              };
            };
          };

          -- TAB 6: Settings
          {
            CardView;
            layout_width = "fill";
            layout_height = "35dp";
            backgroundColor = "0xFF000000";
            cardElevation = "0dp";
            radius = "0dp";
            id = "tab6";
            layout_marginBottom = "0dp";
            {
              LinearLayout;
              orientation = "horizontal";
              layout_width = "fill";
              layout_height = "fill";

              {
                View;
                layout_width = "3dp";
                layout_height = "fill";
                id = "tab6Indicator";
              };

              {
                LinearLayout;
                orientation = "horizontal";
                layout_width = "fill";
                layout_height = "fill";
                gravity = "center_vertical";
                paddingLeft = "15dp";
                {
                  ImageView;
                  layout_width = "24dp";
                  layout_height = "24dp";
                  src = "img/Settings.png";
                  id = "tab6icon";
                  colorFilter = "0xFFFFFFFF";
                };
                {
                  TextView;
                  text = "Settings";
                  textSize = "14sp";
                  textColor = "0xFF8A9AB0";
                  Typeface = Typeface.defaultFromStyle(Typeface.NORMAL);
                  layout_width = "wrap";
                  layout_height = "wrap";
                  layout_marginLeft = "12dp";
                  id = "tab6text";
                };
              };
            };
          };


          {
            CardView;
            layout_width = "fill";
            layout_height = "wrap";
            backgroundColor = "0xFF000000";
            cardElevation = "0dp";
            radius = "0dp";
            layout_marginTop = "10dp";
            layout_marginBottom = "10dp";
            {
              LinearLayout;
              orientation = "horizontal";
              layout_width = "fill";
              layout_height = "wrap";
              gravity = "center_vertical";
              padding = "10dp";
              {
                -- Circle container with border
                CardView;
                layout_width = "50dp";
                layout_height = "50dp";
                cardElevation = "0dp";
                radius = "25dp";
                backgroundColor = "0xFF4A90E2";
                {
                  CardView;
                  layout_width = "46dp";
                  layout_height = "46dp";
                  cardElevation = "0dp";
                  radius = "23dp";
                  backgroundColor = "0xFF000000";
                  layout_gravity = "center";
                  {
                    ImageView;
                    layout_width = "40dp";
                    layout_height = "40dp";
                    src = "icon.png";
                    scaleType = "centerCrop";
                    layout_gravity = "center";
                    id = "avatarIcon";
                  };
                };
              };
              {
                LinearLayout;
                orientation = "vertical";
                layout_width = "0dp";
                layout_weight = "1";
                layout_height = "wrap";
                layout_marginLeft = "10dp";
                {
                  TextView;
                  text = "𝐇𝐄𝐗 • Sev 🅗";
                  textSize = "14sp";
                  textColor = "0xFFFFFFFF";
                  Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                  layout_width = "wrap";
                  layout_height = "wrap";
                  id = "avatarName";
                };
                {
                  TextView;
                  text = "Active";
                  textSize = "12sp";
                  textColor = "0xFF00FF00";
                  layout_width = "wrap";
                  layout_height = "wrap";
                  layout_marginTop = "2dp";
                  id = "avatarStatus";
                };
              };
            };
          };
        };
        
        -- ============================================================
        -- VERTICAL DIVIDER (separates sidebar from content)
        -- ============================================================
        {
          View;
          layout_width = "1dp";
          layout_height = "fill";
          backgroundColor = "0xFF2B2B2B";
        };

        -- ============================================================
        -- RIGHT CONTENT AREA
        -- ============================================================
        {
          LinearLayout;
          Orientation = "vertical";
          layout_height = "fill";
          layout_width = "0dp";
          layout_weight = "1";
          backgroundColor = "0xFF000000";
          id = "featslin";

          -- ============================================================
          -- PAGE VIEW (all 6 pages)
          -- ============================================================
          {
            PageView;
            id = "pg";
            layout_width = "fill";
            layout_height = "fill";
            pages = {

              -- ========================================================
              -- PAGE 0: INFORMATION/MISCELLANEOUS (Developer info)
              -- ========================================================
              {
                LinearLayout;
                orientation = "vertical";
                layout_width = "fill";
                layout_height = "fill";
                padding = "16dp";
                {
                  ScrollView;
                  layout_width = "fill";
                  layout_height = "fill";
                  {
                    LinearLayout;
                    orientation = "vertical";
                    layout_width = "fill";
                    layout_height = "wrap";
                    {
                      CardView;
                      layout_width = "fill";
                      layout_height = "wrap";
                      backgroundColor = "0xFF1A2332";
                      cardElevation = "0dp";
                      radius = "8dp";
                      {
                        LinearLayout;
                        orientation = "vertical";
                        layout_width = "fill";
                        layout_height = "wrap";
                        padding = "16dp";
                        gravity = "center";
                        {
                          TextView;
                          text = "Developer : Sev";
                          textColor = "0xFFFFFFFF";
                          textSize = "18sp";
                          Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                          layout_marginBottom = "10dp";
                          layout_width = "wrap";
                          layout_height = "wrap";
                          gravity = "center";
                        };
                        {
                          TextView;
                          text = "Susano Vertex";
                          textColor = "0xFF8A9AB0";
                          textSize = "14sp";
                          layout_width = "wrap";
                          layout_height = "wrap";
                          gravity = "center";
                        };
                      };
                    };
                  };
                };
              };

              -- ========================================================
              -- PAGE 1: VISUAL (1 CardView with all switches)
              -- ========================================================
              {
                LinearLayout;
                orientation = "vertical";
                layout_width = "fill";
                layout_height = "fill";
                padding = "16dp";
                {
                  ScrollView;
                  layout_width = "fill";
                  layout_height = "fill";
                  {
                    LinearLayout;
                    orientation = "vertical";
                    layout_width = "fill";
                    layout_height = "wrap";
                    {
                      CardView;
                      layout_width = "fill";
                      layout_height = "wrap";
                      backgroundColor = "0x00000000";
                      cardElevation = "0dp";
                      radius = "8dp";
                      id="visualcard1";
                      {
                        LinearLayout;
                        orientation = "vertical";
                        layout_width = "fill";
                        layout_height = "wrap";
                        padding = "12dp";
                        {
                          Switch;
                          text = "WallHack Yellow/Blue";
                          textColor = "0xFFCCCCCC";
                          id = "wyb";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                          layout_marginBottom = "6dp";
                          Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                        };
                        {
                          Switch;
                          text = "WallHack Red";
                          textColor = "0xFFCCCCCC";
                          id = "whr";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                          layout_marginBottom = "6dp";
                          Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                        };
                        {
                          Switch;
                          text = "Br Tags";
                          textColor = "0xFFCCCCCC";
                          id = "brtags";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                          layout_marginBottom = "6dp";
                          Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                        };
                        {
                          Switch;
                          text = "Antenna Red";
                          textColor = "0xFFCCCCCC";
                          id = "antenna";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                          layout_marginBottom = "6dp";
                          Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                        };
                        {
                          Switch;
                          text = "Antenna Cyan";
                          textColor = "0xFFCCCCCC";
                          id = "antenna1";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                          layout_marginBottom = "6dp";
                          Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                        };
                        {
                          Switch;
                          text = "Antenna Black";
                          textColor = "0xFFCCCCCC";
                          id = "antenna2";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                          Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                        };
                      };
                    };
                  };
                };
              };

              -- ========================================================
              -- PAGE 2: GUN AIM (1 CardView with all switches)
              -- ========================================================
              {
                LinearLayout;
                orientation = "vertical";
                layout_width = "fill";
                layout_height = "fill";
                padding = "16dp";
                {
                  ScrollView;
                  layout_width = "fill";
                  layout_height = "fill";
                  {
                    LinearLayout;
                    orientation = "vertical";
                    layout_width = "fill";
                    layout_height = "wrap";
                    {
                      CardView;
                      layout_width = "fill";
                      layout_height = "wrap";
                      backgroundColor = "0xFF1A2332";
                      cardElevation = "0dp";
                      radius = "8dp";
                      {
                        LinearLayout;
                        orientation = "vertical";
                        layout_width = "fill";
                        layout_height = "wrap";
                        padding = "12dp";
                        {
                          Switch;
                          text = "Gun Aim Feature 1";
                          textColor = "0xFFCCCCCC";
                          id = "gunaim1";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                          layout_marginBottom = "6dp";
                        };
                        {
                          Switch;
                          text = "Gun Aim Feature 2";
                          textColor = "0xFFCCCCCC";
                          id = "gunaim2";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                          layout_marginBottom = "6dp";
                        };
                        {
                          Switch;
                          text = "Gun Aim Feature 3";
                          textColor = "0xFFCCCCCC";
                          id = "gunaim3";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                          layout_marginBottom = "6dp";
                        };
                        {
                          Switch;
                          text = "Gun Aim Feature 4";
                          textColor = "0xFFCCCCCC";
                          id = "gunaim4";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                          layout_marginBottom = "6dp";
                        };
                        {
                          Switch;
                          text = "Gun Aim Feature 5";
                          textColor = "0xFFCCCCCC";
                          id = "gunaim5";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                          layout_marginBottom = "6dp";
                        };
                        {
                          Switch;
                          text = "Gun Aim Feature 6";
                          textColor = "0xFFCCCCCC";
                          id = "gunaim6";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                        };
                      };
                    };
                  };
                };
              };

              -- ========================================================
              -- PAGE 3: MEMORY (sub-tabs: ABILITY / ADJUSTABLE)
              -- ========================================================
              {
                LinearLayout;
                orientation = "vertical";
                layout_width = "fill";
                layout_height = "fill";
                {
                  -- Memory sub-tab bar
                  LinearLayout;
                  orientation = "horizontal";
                  layout_width = "fill";
                  layout_height = "wrap";
                  backgroundColor = "0xFF0E1118";
                  padding = "10dp";
                  {
                    CardView;
                    layout_width = "0dp";
                    layout_weight = "1";
                    layout_height = "34dp";
                    backgroundColor = "0xFF1A1A2E";
                    cardElevation = "0dp";
                    radius = "6dp";
                    layout_marginRight = "5dp";
                    id = "memorySubTab1";
                    {
                      TextView;
                      text = "ABILITY";
                      textSize = "11sp";
                      textColor = "0xFF6B6B7B";
                      Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                      gravity = "center";
                      layout_width = "fill";
                      layout_height = "fill";
                      id = "memorySubTab1Text";
                    };
                  };
                  {
                    CardView;
                    layout_width = "0dp";
                    layout_weight = "1";
                    layout_height = "34dp";
                    backgroundColor = "0xFF1A1A2E";
                    cardElevation = "0dp";
                    radius = "6dp";
                    layout_marginLeft = "5dp";
                    id = "memorySubTab2";
                    {
                      TextView;
                      text = "ADJUSTABLE";
                      textSize = "11sp";
                      textColor = "0xFF6B6B7B";
                      Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                      gravity = "center";
                      layout_width = "fill";
                      layout_height = "fill";
                      id = "memorySubTab2Text";
                    };
                  };
                };
                {
                  FrameLayout;
                  layout_width = "fill";
                  layout_height = "0dp";
                  layout_weight = "1";

                  -- ABILITY content
                  {
                    LinearLayout;
                    orientation = "vertical";
                    layout_width = "fill";
                    layout_height = "fill";
                    padding = "14dp";
                    id = "memoryAbilityContent";
                    {
                      ScrollView;
                      layout_width = "fill";
                      layout_height = "fill";
                      {
                        LinearLayout;
                        orientation = "vertical";
                        layout_width = "fill";
                        layout_height = "wrap";
                        {
                          Switch;
                          text = "BR TAGS";
                          textColor = "0xFFCCCCCC";
                          id = "brtags1";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                          layout_marginBottom = "6dp";
                        };
                        {
                          Switch;
                          text = "WALLHACK Y/B";
                          textColor = "0xFFCCCCCC";
                          id = "wyb1";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                          layout_marginBottom = "6dp";
                        };
                        {
                          Switch;
                          text = "WALLHACK RED";
                          textColor = "0xFFCCCCCC";
                          id = "whr1";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                          layout_marginBottom = "6dp";
                        };
                        {
                          Switch;
                          text = "No Recoil";
                          textColor = "0xFFCCCCCC";
                          id = "Nrecoil1";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                          layout_marginBottom = "6dp";
                        };
                        {
                          Switch;
                          text = "No Spread1";
                          textColor = "0xFFCCCCCC";
                          id = "Nspread";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                          layout_marginBottom = "6dp";
                        };
                        {
                          Switch;
                          text = "No Reload";
                          textColor = "0xFFCCCCCC";
                          id = "Nreload1";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                          layout_marginBottom = "6dp";
                        };
                      };
                    };
                  };

                  -- ADJUSTABLE content (seekbars)
                  {
                    LinearLayout;
                    orientation = "vertical";
                    layout_width = "fill";
                    layout_height = "fill";
                    padding = "14dp";
                    id = "memoryAimbotContent";
                    visibility = "gone";
                    {
                      ScrollView;
                      layout_width = "fill";
                      layout_height = "fill";
                      {
                        LinearLayout;
                        orientation = "vertical";
                        layout_width = "fill";
                        layout_height = "wrap";
                        {
                          TextView;
                          text="ᴀɪᴍʙᴏᴛ (0%)";
                          textColor="0xFFCCCCCC";
                          textSize="14sp";
                          layout_width="fill";
                          layout_height="wrap";
                          layout_gravity="center";
                          id="aimbot_text";
                        };
                        {
                          SeekBar;
                          layout_width="fill";
                          layout_height="wrap";
                          max=100;
                          progress=0;
                          id="aimbot_seekbar";
                        };
                        {
                          TextView;
                          text="ꜰᴏᴠ 3ʀᴅ ᴘᴇʀꜱᴏɴ ᴀᴅᴊᴜꜱᴛᴀʙʟᴇ (0%)";
                          textColor="0xFFCCCCCC";
                          textSize="14sp";
                          layout_width="fill";
                          layout_height="wrap";
                          layout_gravity="center";
                          id="Fov_text";
                        };
                        {
                          SeekBar;
                          layout_width="fill";
                          layout_height="wrap";
                          max=300;
                          progress=0;
                          id="Fov_seekbar";
                        };
                        {
                          TextView;
                          text="sɴᴏᴡʙᴏᴀʀᴅ sᴘᴇᴇᴅ (0%)";
                          textColor="0xFFCCCCCC";
                          textSize="14sp";
                          layout_width="fill";
                          layout_height="wrap";
                          layout_gravity="center";
                          id="snowboard_text";
                        };
                        {
                          SeekBar;
                          layout_width="fill";
                          layout_height="wrap";
                          max=100;
                          progress=0;
                          id="snowboard_seekbar";
                        };
                      };
                    };
                  };
                };
              };

              -- ========================================================
              -- PAGE 4: SKIN CHANGER (sub-tabs: GUN / CHARACTER / MELEE)
              -- ========================================================
              {
                LinearLayout;
                orientation = "vertical";
                layout_width = "fill";
                layout_height = "fill";
                {
                  -- Skins sub-tab bar
                  LinearLayout;
                  orientation = "horizontal";
                  layout_width = "fill";
                  layout_height = "wrap";
                  backgroundColor = "0xFF0E1118";
                  padding = "10dp";
                  {
                    CardView;
                    layout_width = "0dp";
                    layout_weight = "1";
                    layout_height = "34dp";
                    backgroundColor = "0xFF1A1A2E";
                    cardElevation = "0dp";
                    radius = "6dp";
                    layout_marginRight = "3dp";
                    id = "skinsSubTab1";
                    {
                      TextView;
                      text = "GUN";
                      textSize = "11sp";
                      textColor = "0xFF6B6B7B";
                      Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                      gravity = "center";
                      layout_width = "fill";
                      layout_height = "fill";
                      id = "skinsSubTab1Text";
                    };
                  };
                  {
                    CardView;
                    layout_width = "0dp";
                    layout_weight = "1";
                    layout_height = "34dp";
                    backgroundColor = "0xFF1A1A2E";
                    cardElevation = "0dp";
                    radius = "6dp";
                    layout_marginLeft = "3dp";
                    layout_marginRight = "3dp";
                    id = "skinsSubTab2";
                    {
                      TextView;
                      text = "CHARACTER";
                      textSize = "11sp";
                      textColor = "0xFF6B6B7B";
                      Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                      gravity = "center";
                      layout_width = "fill";
                      layout_height = "fill";
                      id = "skinsSubTab2Text";
                    };
                  };
                  {
                    CardView;
                    layout_width = "0dp";
                    layout_weight = "1";
                    layout_height = "34dp";
                    backgroundColor = "0xFF1A1A2E";
                    cardElevation = "0dp";
                    radius = "6dp";
                    layout_marginLeft = "3dp";
                    id = "skinsSubTab3";
                    {
                      TextView;
                      text = "MELEE";
                      textSize = "11sp";
                      textColor = "0xFF6B6B7B";
                      Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                      gravity = "center";
                      layout_width = "fill";
                      layout_height = "fill";
                      id = "skinsSubTab3Text";
                    };
                  };
                };
                {
                  FrameLayout;
                  layout_width = "fill";
                  layout_height = "0dp";
                  layout_weight = "1";

                  -- GUN content
                  {
                    LinearLayout;
                    orientation = "vertical";
                    layout_width = "fill";
                    layout_height = "fill";
                    padding = "14dp";
                    id = "skinsBasicContent";
                    {
                      ScrollView;
                      layout_width = "fill";
                      layout_height = "fill";
                      {
                        LinearLayout;
                        orientation = "vertical";
                        layout_width = "fill";
                        layout_height = "wrap";
                        {
                          TextView;
                          text = "Use AK117 Gun";
                          textSize = "18sp";
                          textColor = "0xFF6B6B7B";
                          Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                          gravity = "center";
                          layout_width = "fill";
                          layout_height = "wrap";
                          layout_marginBottom = "10dp";
                        };
                        {
                          CheckBox;
                          text = "Ak117 Mythic";
                          textColor = "0xFFCCCCCC";
                          id = "ak117";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                          layout_marginBottom = "6dp";
                        };
                        {
                          CheckBox;
                          text = "Bp50 Mythic";
                          textColor = "0xFFCCCCCC";
                          id = "bp50";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                          layout_marginBottom = "6dp";
                        };
                        {
                          CheckBox;
                          text = "Grau Mythic";
                          textColor = "0xFFCCCCCC";
                          id = "grau";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                        };
                      };
                    };
                  };

                  -- CHARACTER content
                  {
                    LinearLayout;
                    orientation = "vertical";
                    layout_width = "fill";
                    layout_height = "fill";
                    padding = "14dp";
                    id = "skinsWorldContent";
                    visibility = "gone";
                    {
                      ScrollView;
                      layout_width = "fill";
                      layout_height = "fill";
                      {
                        LinearLayout;
                        orientation = "vertical";
                        layout_width = "fill";
                        layout_height = "wrap";
                        {
                          TextView;
                          text = "Use Charly";
                          textSize = "18sp";
                          textColor = "0xFF6B6B7B";
                          Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                          gravity = "center";
                          layout_width = "fill";
                          layout_height = "wrap";
                          layout_marginBottom = "10dp";
                        };
                        {
                          RadioButton;
                          text = "TEMPLAR MYTHIC";
                          textColor = "0xFFCCCCCC";
                          id = "templar";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                          layout_marginBottom = "6dp";
                        };
                        {
                          RadioButton;
                          text = "SIREN MYTHIC";
                          textColor = "0xFFCCCCCC";
                          id = "siren";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                          layout_marginBottom = "6dp";
                        };
                        {
                          RadioButton;
                          text = "SOPHIA MYTHIC";
                          textColor = "0xFFCCCCCC";
                          id = "sophia";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                          layout_marginBottom = "6dp";
                        };
                        {
                          RadioButton;
                          text = "NYX MYTHIC";
                          textColor = "0xFFCCCCCC";
                          id = "nyx";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                          layout_marginBottom = "6dp";
                        };
                        {
                          RadioButton;
                          text = "SPECTRE MYTHIC";
                          textColor = "0xFFCCCCCC";
                          id = "spectre";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                          layout_marginBottom = "6dp";
                        };
                        {
                          RadioButton;
                          text = "GHOST MYTHIC";
                          textColor = "0xFFCCCCCC";
                          id = "ghost";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                          layout_marginBottom = "6dp";
                        };
                      };
                    };
                  };

                  -- MELEE content
                  {
                    LinearLayout;
                    orientation = "vertical";
                    layout_width = "fill";
                    layout_height = "fill";
                    padding = "14dp";
                    id = "skinsCustmiseContent";
                    visibility = "gone";
                    {
                      ScrollView;
                      layout_width = "fill";
                      layout_height = "fill";
                      {
                        LinearLayout;
                        orientation = "vertical";
                        layout_width = "fill";
                        layout_height = "wrap";
                        {
                          TextView;
                          text = "Use Normal Skin";
                          textSize = "18sp";
                          textColor = "0xFF6B6B7B";
                          Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                          gravity = "center";
                          layout_width = "fill";
                          layout_height = "wrap";
                          layout_marginBottom = "10dp";
                        };
                        {
                          RadioButton;
                          text = "Tang Knife";
                          textColor = "0xFFCCCCCC";
                          id = "tang";
                          textSize = "12sp";
                          layout_width = "fill";
                          layout_height = "wrap";
                        };
                      };
                    };
                  };
                };
              };

              -- ========================================================
              -- PAGE 5: SETTINGS (FPS toggle + Exit)
              -- ========================================================
              {
                LinearLayout;
                orientation = "vertical";
                layout_width = "fill";
                layout_height = "fill";
                padding = "16dp";
                {
                  ScrollView;
                  layout_width = "fill";
                  layout_height = "fill";
                  {
                    LinearLayout;
                    orientation = "vertical";
                    layout_width = "fill";
                    layout_height = "wrap";
                    {
                      CardView;
                      layout_width = "fill";
                      layout_height = "wrap";
                      backgroundColor = "0xFF1A2332";
                      cardElevation = "0dp";
                      radius = "8dp";
                      {
                        LinearLayout;
                        orientation = "vertical";
                        layout_width = "fill";
                        layout_height = "wrap";
                        padding = "12dp";
                        {
                          ToggleButton;
                          textOff="SHOW FPS";
                          textColor="0xFFFFFFFF";
                          backgroundColor="0x70FFFFFF";
                          id="showfps";
                          textSize="11sp";
                          layout_width="fill";
                          textOn="HIDE FPS";
                          layout_height="wrap";
                          layout_marginBottom="4dp";
                        };
                        {
                          Button;
                          text = "Exit Menu";
                          textColor = "0xFFFFFFFF";
                          backgroundColor = "0xFFE74C3C";
                          id = "exitmenuu";
                          textSize = "13sp";
                          layout_width = "fill";
                          layout_height = "45dp";
                        };
                      };
                    };
                  };
                };
              };

            };  -- end pages
          };
        };
      };
    };
  };
};

minlay2 = {
  LinearLayout;
  layout_width="wrap";
  layout_height="wrap";
  id="jumpmenu";
  {
    ImageView;
    layout_width="70dp";
    layout_height="70dp";
    src="icon.png";
    id="Win_minWindow11";
    padding="8dp";
    onClick=function()
      if OpenM==false then
        Waterdropanimation(Win_minWindow11, 50)
        OpenM=true
        LayoutVIP1.removeView(minWindow)
        LayoutVIP1.addView(mainWindow1, WmHz1)
        showCyberpunkToast("Menu Show")
      end
    end;
  };
};

LayoutVIP1 = activity.getSystemService(Context.WINDOW_SERVICE)
LayoutVIP = activity.getSystemService(Context.WINDOW_SERVICE)
HasFocus = false

WmHz1 = WindowManager.LayoutParams()
if Build.VERSION.SDK_INT >= 26 then
  WmHz1.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
 else
  WmHz1.type = WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
end
import "android.graphics.PixelFormat"
WmHz1.format = PixelFormat.RGBA_8888
WmHz1.flags = WindowManager.LayoutParams().FLAG_NOT_FOCUSABLE
WmHz1.gravity = Gravity.CENTER
WmHz1.x = 0
WmHz1.y = 0
WmHz1.width = WindowManager.LayoutParams.WRAP_CONTENT
WmHz1.height = WindowManager.LayoutParams.WRAP_CONTENT
mainWindow1 = loadlayout(layout2)

A3params1 = WindowManager.LayoutParams()
if Build.VERSION.SDK_INT >= 26 then
  A3params1.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
 else
  A3params1.type = WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
end
A3params1.format = PixelFormat.RGBA_8888
A3params1.flags = WindowManager.LayoutParams().FLAG_NOT_FOCUSABLE
A3params1.gravity = Gravity.TOP | Gravity.LEFT
A3params1.x = 50
A3params1.y = 100
A3params1.width = WindowManager.LayoutParams.WRAP_CONTENT
A3params1.height = WindowManager.LayoutParams.WRAP_CONTENT
minWindow = loadlayout(minlay2)

OpenM = false
isMax1 = true


LayoutVIP3=activity.getSystemService(Context.WINDOW_SERVICE)
HasFocus=false
WmHz3 =WindowManager.LayoutParams()
if Build.VERSION.SDK_INT >= 26 then WmHz3.type =WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
 else WmHz3.type =WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
end
import "android.graphics.PixelFormat"
WmHz3.format =PixelFormat.RGBA_8888
WmHz3.flags=WindowManager.LayoutParams().FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
WmHz3.gravity = Gravity.CENTER| Gravity.TOP
WmHz3.x = 0
WmHz3.y = 0
minWindow5 = loadlayout(fpsmeter)




function menu.OnTouchListener(v, event)
  if event.getAction() == MotionEvent.ACTION_DOWN then
    firstX = event.getRawX()
    firstY = event.getRawY()
    wmX = WmHz1.x
    wmY = WmHz1.y
   elseif event.getAction() == MotionEvent.ACTION_MOVE then
    WmHz1.x = wmX + (event.getRawX() - firstX)
    WmHz1.y = wmY + (event.getRawY() - firstY)
    LayoutVIP1.updateViewLayout(mainWindow1, WmHz1)
   elseif event.getAction() == MotionEvent.ACTION_UP then
  end
  return true
end

-- CircleButtonAsh function (gradient + stroke styling)
function CircleButtonAsh(view, Grad, Col, radiu, InsideColor1)
  import "android.graphics.drawable.GradientDrawable"
  drawable = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, {Grad, Col})
  drawable.setShape(GradientDrawable.RECTANGLE)
  drawable.setCornerRadii({radiu, radiu, radiu, radiu, radiu, radiu, radiu, radiu})
  drawable.setStroke(2.1, InsideColor1)
  view.setBackgroundDrawable(drawable)
end


function CircleButtonTab(view,InsideColor,radiu,InsideColor1)
  import "android.graphics.drawable.GradientDrawable"
  drawable = GradientDrawable()
  drawable.setShape(GradientDrawable.RECTANGLE)
  drawable.setCornerRadii({radiu, radiu, radiu, radiu, radiu, radiu, radiu, radiu})
  drawable.setColor(InsideColor)
  drawable.setStroke(2, InsideColor1)
  view.setBackgroundDrawable(drawable)
end


function CircleButton(view,InsideColor,radiu,InsideColor1)
  import "android.graphics.drawable.GradientDrawable"
  drawable = GradientDrawable()
  drawable.setShape(GradientDrawable.RECTANGLE)
  drawable.setCornerRadii({radiu, radiu, radiu, radiu, radiu, radiu, radiu, radiu})
  drawable.setColor(InsideColor)
  drawable.setStroke(2, InsideColor1)
  view.setBackgroundDrawable(drawable)
end


function BottomOutlineButton(view, bgColor, strokeColor, radius)
  import "android.graphics.drawable.GradientDrawable"
  import "android.graphics.drawable.LayerDrawable"

  -- Background
  local bg = GradientDrawable()
  bg.setShape(GradientDrawable.RECTANGLE)
  bg.setCornerRadii({
    radius, radius,
    radius, radius,
    radius, radius,
    radius, radius
  })
  bg.setColor(bgColor)

  -- Bottom stroke (fake stroke using height)
  local stroke = GradientDrawable()
  stroke.setShape(GradientDrawable.RECTANGLE)
  stroke.setColor(strokeColor)

  local layers = {
    bg,
    stroke
  }

  local drawable = LayerDrawable(layers)

  -- Push the stroke to bottom (2dp height)
  drawable.setLayerInset(1, 0, view.getHeight() - 2, 0, 0)

  view.post(function()
    drawable.setLayerInset(1, 0, view.getHeight() - 2, 0, 0)
  end)

  view.setBackgroundDrawable(drawable)
end


function LeftOutlineButton(view, bgColor, strokeColor, radius)
  import "android.graphics.drawable.GradientDrawable"
  import "android.graphics.drawable.LayerDrawable"

  -- Background
  local bg = GradientDrawable()
  bg.setShape(GradientDrawable.RECTANGLE)
  bg.setCornerRadii({
    radius, radius,
    radius, radius,
    radius, radius,
    radius, radius
  })
  bg.setColor(bgColor)

  -- Left stroke (fake stroke using width)
  local stroke = GradientDrawable()
  stroke.setShape(GradientDrawable.RECTANGLE)
  stroke.setColor(strokeColor)

  local layers = {
    bg,
    stroke
  }

  local drawable = LayerDrawable(layers)

  -- Push the stroke to left (2dp width)
  view.post(function()
    local width = 2  -- stroke thickness
    drawable.setLayerInset(1, 0, 0, view.getWidth() - width, 0)
    view.setBackgroundDrawable(drawable)
  end)
end

LeftOutlineButton(cardex, 0x00000000, 0xFF2B2B2B, 0)


CircleButton(menu,0xFF000000, 20, 0xFF000000)

-- Tab name map for header indicator (6 tabs)
local tabNameMap = {
  [1] = "Visuals",
  [2] = "Aimbot",
  [3] = "Memory",
  [4] = "Miscellaneous",
  [5] = "Skins",
  [6] = "Settings"
}


function updateTabStyles(activeTab)
  -- Hide all indicators
  tab1Indicator.setBackgroundColor(0x00000000)
  tab2Indicator.setBackgroundColor(0x00000000)
  tab3Indicator.setBackgroundColor(0x00000000)
  tab4Indicator.setBackgroundColor(0x00000000)
  tab5Indicator.setBackgroundColor(0x00000000)
  tab6Indicator.setBackgroundColor(0x00000000)

  -- INACTIVE tabs → bottom outline only
  BottomOutlineButton(tab1, 0x00000000, 0xFF2B2B2B, 0)
  BottomOutlineButton(tab2, 0x00000000, 0xFF2B2B2B, 0)
  BottomOutlineButton(tab3, 0x00000000, 0xFF2B2B2B, 0)
  BottomOutlineButton(tab4, 0x00000000, 0xFF2B2B2B, 0)
  BottomOutlineButton(tab5, 0x00000000, 0xFF2B2B2B, 0)
  BottomOutlineButton(tab6, 0x00000000, 0xFF2B2B2B, 0)

  -- Text inactive
  tab1text.setTextColor(0xFF8A9AB0)
  tab2text.setTextColor(0xFF8A9AB0)
  tab3text.setTextColor(0xFF8A9AB0)
  tab4text.setTextColor(0xFF8A9AB0)
  tab5text.setTextColor(0xFF8A9AB0)
  tab6text.setTextColor(0xFF8A9AB0)

  -- ACTIVE tab → SAME AS BEFORE (CircleButtonAsh)
  if activeTab == tab1 then
    tab1Indicator.setBackgroundColor(0xFFFFFFFF)
    CircleButtonAsh(tab1, 0xFF00C9A7, 0x00000000, 0, 0x00000000)
    tab1text.setTextColor(0xFF000000)

  elseif activeTab == tab2 then
    tab2Indicator.setBackgroundColor(0xFFFFFFFF)
    CircleButtonAsh(tab2, 0xFF00C9A7, 0x00000000, 0, 0x00000000)
    tab2text.setTextColor(0xFF000000)

  elseif activeTab == tab3 then
    tab3Indicator.setBackgroundColor(0xFFFFFFFF)
    CircleButtonAsh(tab3, 0xFF00C9A7, 0x00000000, 0, 0x00000000)
    tab3text.setTextColor(0xFF000000)

  elseif activeTab == tab4 then
    tab4Indicator.setBackgroundColor(0xFFFFFFFF)
    CircleButtonAsh(tab4, 0xFF00C9A7, 0x00000000, 0, 0x00000000)
    tab4text.setTextColor(0xFF000000)

  elseif activeTab == tab5 then
    tab5Indicator.setBackgroundColor(0xFFFFFFFF)
    CircleButtonAsh(tab5, 0xFF00C9A7, 0x00000000, 0, 0x00000000)
    tab5text.setTextColor(0xFF000000)

  elseif activeTab == tab6 then
    tab6Indicator.setBackgroundColor(0xFFFFFFFF)
    CircleButtonAsh(tab6, 0xFF00C9A7, 0x00000000, 0, 0x00000000)
    tab6text.setTextColor(0xFF000000)
  end
end



function updateSkinsSubTabs(activeSubTab)
  CircleButtonAsh(skinsSubTab1, 0xFF1A1A2E, 0xFF1A1A2E, 8, 0xFF2D2D3D)
  CircleButtonAsh(skinsSubTab2, 0xFF1A1A2E, 0xFF1A1A2E, 8, 0xFF2D2D3D)
  CircleButtonAsh(skinsSubTab3, 0xFF1A1A2E, 0xFF1A1A2E, 8, 0xFF2D2D3D)

  skinsSubTab1Text.setTextColor(0xFF6B6B7B)
  skinsSubTab2Text.setTextColor(0xFF6B6B7B)
  skinsSubTab3Text.setTextColor(0xFF6B6B7B)

  skinsBasicContent.setVisibility(View.GONE)
  skinsWorldContent.setVisibility(View.GONE)
  skinsCustmiseContent.setVisibility(View.GONE)

  if activeSubTab == "basic" then
    CircleButtonAsh(skinsSubTab1, 0xFF8B5CF6, 0xFF6D28D9, 8, 0xFF8B5CF6)
    skinsSubTab1Text.setTextColor(0xFFFFFFFF)
    skinsBasicContent.setVisibility(View.VISIBLE)
   elseif activeSubTab == "world" then
    CircleButtonAsh(skinsSubTab2, 0xFF8B5CF6, 0xFF6D28D9, 8, 0xFF8B5CF6)
    skinsSubTab2Text.setTextColor(0xFFFFFFFF)
    skinsWorldContent.setVisibility(View.VISIBLE)
   elseif activeSubTab == "custmise" then
    CircleButtonAsh(skinsSubTab3, 0xFF8B5CF6, 0xFF6D28D9, 8, 0xFF8B5CF6)
    skinsSubTab3Text.setTextColor(0xFFFFFFFF)
    skinsCustmiseContent.setVisibility(View.VISIBLE)
  end
end

function updateMemorySubTabs(activeSubTab)
  CircleButtonAsh(memorySubTab1, 0xFF1A1A2E, 0xFF1A1A2E, 8, 0xFF2D2D3D)
  CircleButtonAsh(memorySubTab2, 0xFF1A1A2E, 0xFF1A1A2E, 8, 0xFF2D2D3D)

  memorySubTab1Text.setTextColor(0xFF6B6B7B)
  memorySubTab2Text.setTextColor(0xFF6B6B7B)

  memoryAbilityContent.setVisibility(View.GONE)
  memoryAimbotContent.setVisibility(View.GONE)

  if activeSubTab == "ability" then
    CircleButtonAsh(memorySubTab1, 0xFF8B5CF6, 0xFF6D28D9, 8, 0xFF8B5CF6)
    memorySubTab1Text.setTextColor(0xFFFFFFFF)
    memoryAbilityContent.setVisibility(View.VISIBLE)
   elseif activeSubTab == "aimbot" then
    CircleButtonAsh(memorySubTab2, 0xFF8B5CF6, 0xFF6D28D9, 8, 0xFF8B5CF6)
    memorySubTab2Text.setTextColor(0xFFFFFFFF)
    memoryAimbotContent.setVisibility(View.VISIBLE)
  end
end

-- ============================================================
-- Main tab click handlers (6 tabs)
-- Page order: 0=Information, 1=Visual, 2=Gun Aim, 3=Memory, 4=Skins, 5=Settings
-- New tab order: 1=Visuals, 2=Aimbot, 3=Memory, 4=Miscellaneous, 5=Skins, 6=Settings
-- ============================================================
function tab1.onClick()
  updateTabStyles(tab1)
  pg.showPage(1) -- Visual page
end

function tab2.onClick()
  updateTabStyles(tab2)
  pg.showPage(2) -- Gun Aim (Aimbot) page
end

function tab3.onClick()
  updateTabStyles(tab3)
  pg.showPage(3) -- Memory page
  updateMemorySubTabs(currentMemorySubTab)
end

function tab4.onClick()
  updateTabStyles(tab4)
  pg.showPage(0) -- Information/Miscellaneous page
end

function tab5.onClick()
  updateTabStyles(tab5)
  pg.showPage(4) -- Skins page
  updateSkinsSubTabs(currentSkinsSubTab)
end

function tab6.onClick()
  updateTabStyles(tab6)
  pg.showPage(5) -- Settings page
end

-- Skins sub-tab handlers
function skinsSubTab1.onClick()
  currentSkinsSubTab = "basic"
  updateSkinsSubTabs("basic")
end

function skinsSubTab2.onClick()
  currentSkinsSubTab = "world"
  updateSkinsSubTabs("world")
end

function skinsSubTab3.onClick()
  currentSkinsSubTab = "custmise"
  updateSkinsSubTabs("custmise")
end

-- Memory sub-tab handlers
function memorySubTab1.onClick()
  currentMemorySubTab = "ability"
  updateMemorySubTabs("ability")
end

function memorySubTab2.onClick()
  currentMemorySubTab = "aimbot"
  updateMemorySubTabs("aimbot")
end

function showfps.onClick()
  showCyberpunkToast("FPS Display Enabled")
end

import "android.graphics.drawable.LayerDrawable"


import "android.graphics.drawable.StateListDrawable"


local COLOR_SWITCH_ON = 0xFF00D9C0  -- Cyan/turquoise
local COLOR_SWITCH_OFF = 0xFF2A2A2A  -- Dark gray


local switches = {brtags, wyb, whr, antenna, antenna1, antenna2}
for i, sw in ipairs(switches) do
  local function createSwitchTrack(isChecked)
    local gd = GradientDrawable()
    gd.setCornerRadius(60)  -- Pill shape
    gd.setColor(isChecked and COLOR_SWITCH_ON or COLOR_SWITCH_OFF)  -- Fill color inside
    -- Glowing cyan outline when active, dark outline when inactive
    gd.setStroke(4, isChecked and 0xFF00FFF0 or 0xFF000000)  -- Bright cyan glow or black
    return gd
  end

  local trackStates = StateListDrawable()
  trackStates.addState({android.R.attr.state_checked}, createSwitchTrack(true))
  trackStates.addState({-android.R.attr.state_checked}, createSwitchTrack(false))
  sw.setTrackDrawable(trackStates)

  -- Create white circular thumb with outline (smaller size)
  local thumb = GradientDrawable()
  thumb.setShape(GradientDrawable.OVAL)
  thumb.setSize(40, 40)  -- Even smaller thumb
  thumb.setColor(0xFF00FFF0)  -- White fill
  thumb.setStroke(8, 0xFF00FFF0)  -- Black outline around the circle
  sw.setThumbDrawable(thumb)

  sw.setOnCheckedChangeListener(function(view, checked)
    local states = StateListDrawable()
    states.addState({android.R.attr.state_checked}, createSwitchTrack(true))
    states.addState({-android.R.attr.state_checked}, createSwitchTrack(false))
    view.setTrackDrawable(states)
  end)
end



function exitmenuu.onClick()
  LayoutVIP1.removeView(mainWindow1)
  LayoutVIP1.removeView(minWindow)
  LayoutVIP3.removeView(minWindow5)
  OpenM = false
  showCyberpunkToast("Menu Exited")
  start.setChecked(false)
end


function Waterdropanimation(Controls,time)
  import "android.animation.ObjectAnimator"
  ObjectAnimator().ofFloat(Controls,"scaleX",{1,.8,1.3,.9,1}).setDuration(time).start()
  ObjectAnimator().ofFloat(Controls,"scaleY",{1,.8,1.3,.9,1}).setDuration(time).start()
end


function SansFont(ido, file)
  ido.setTypeface(Typeface.createFromFile(File(file)))
end

local fontPath = activity.getLuaDir() .. "/Font/Title.ttf"
if File(fontPath).exists() then
  SansFont(tit1, fontPath)
end




function formatMemory(kb)
  if kb < 1024 then
    return string.format("%.2f KB", kb)
  end
  local mb = kb / 1024
  if mb < 1024 then
    return string.format("%.2f MB", mb)
  end
  return string.format("%.2f GB", mb / 1024)
end

function getMemoryInfo()
  local memInfo = {}
  local success, err = pcall(function()
    for line in io.lines("/proc/meminfo") do
      local k, v = line:match("([^:]+):%s+(%d+).+")
      if k and v then
        memInfo[k] = tonumber(v)
      end
    end
  end)

  if not success then
    print("Error reading meminfo: " .. err)
    return nil
  end
  return memInfo
end

function getChipsetInfo()
  local chipset = "Unknown"

  local success, err = pcall(function()
    local f = io.open("/proc/device-tree/model", "r")
    if f then
      chipset = f:read("*a"):gsub("\0", ""):gsub("\n", "")
      f:close()
      return chipset
    end
  end)

  if not success then
    print("Error reading device tree: " .. tostring(err))
  end

  local success, cpuInfo = pcall(function()
    local f = io.popen("cat /proc/cpuinfo 2>/dev/null")
    if f then
      local content = f:read("*a")
      f:close()
      return content
    end
    return nil
  end)

  if success and cpuInfo then
    chipset = cpuInfo:match("Hardware%s+: (%S+)") or
    cpuInfo:match("model name%s+: ([^\n]+)") or
    cpuInfo:match("Processor%s+: ([^\n]+)") or
    chipset
  end

  local success, lscpu = pcall(function()
    local f = io.popen("lscpu 2>/dev/null")
    if f then
      local content = f:read("*a")
      f:close()
      return content
    end
    return nil
  end)

  if success and lscpu then
    chipset = lscpu:match("Model name%s+: ([^\n]+)") or
    lscpu:match("Architecture%s+: ([^\n]+)") or
    chipset
  end

  chipset = chipset:gsub("%s+$", ""):gsub("^%s+", "")
  if chipset == "" then chipset = "Unknown" end

  return chipset
end

function safeSetText(view, text)
  if view and view.setText then
    pcall(function() view.setText(tostring(text)) end)
  end
end

function safeSetProgress(progressBar, value)
  if progressBar and progressBar.setProgress then
    pcall(function() progressBar.setProgress(tonumber(value) or 0) end)
  end
end

function safeSetTextColor(view, color)
  if view and view.setTextColor then
    pcall(function() view.setTextColor(tonumber(color) or 0xFF000000) end)
  end
end

function updateRamUsage()
  local memInfo = getMemoryInfo()
  if not memInfo or not memInfo.MemTotal then
    safeSetText(ram_percentage, "Error")
    return
  end

  local total = memInfo.MemTotal
  local available = memInfo.MemAvailable or
  (memInfo.MemFree or 0) +
  (memInfo.Buffers or 0) +
  (memInfo.Cached or 0) +
  (memInfo.SReclaimable or 0)

  local used = total - available

  used = math.max(0, math.min(used, total))
  available = math.max(0, math.min(available, total))

  local usagePercentage = math.floor((used / total) * 100 + 0.5)

  safeSetProgress(ram_progress, usagePercentage)
  safeSetText(ram_percentage, usagePercentage.."%")
  safeSetText(ram_used, formatMemory(used))
  safeSetText(ram_free, formatMemory(available))
  safeSetText(ram_total, formatMemory(total))

  if usagePercentage > 85 then
    safeSetTextColor(ram_percentage, 0xFFFF5252)
   elseif usagePercentage > 70 then
    safeSetTextColor(ram_percentage, 0xFFFFC107)
   else
    safeSetTextColor(ram_percentage, 0xFF4CAF50)
  end

  if not chipset_initialized then
    safeSetText(device_chipset, getChipsetInfo())
    chipset_initialized = true
  end
end

chipset_initialized = false
local updateCount = 0
local isRunning = true


local ramUpdateHandler = Handler()
local updateRunnable = Runnable({
  run = function()
    if not isRunning then return end

    local success, err = pcall(updateRamUsage)
    if not success then
      print("Error in updateRamUsage: " .. tostring(err))
    end

    updateCount = updateCount + 1
    if updateCount < 5 then
      if ramUpdateHandler then
        ramUpdateHandler.postDelayed(updateRunnable, 1000)
      end
     else

      stopRamMonitoring()
    end
  end
})

function stopRamMonitoring()
  isRunning = false
  if ramUpdateHandler then
    ramUpdateHandler.removeCallbacks(updateRunnable)
    ramUpdateHandler = nil
  end
  updateRunnable = nil
end

if ramUpdateHandler then
  ramUpdateHandler.post(updateRunnable)
end

function onDestroy()
  stopRamMonitoring()
end




function createToastBackground()
  local gd = GradientDrawable()
  gd.setShape(GradientDrawable.RECTANGLE)
  gd.setCornerRadius(20)
  gd.setColor(0x00000000)
  gd.setStroke(3, 0xFFFFFFFF)
  return gd
end

cstmToast = {
  LinearLayout;
  layout_width = "wrap";
  layout_height = "wrap";
  gravity = "center_vertical";
  orientation = "horizontal";
  padding = "10dp";
  background = 0;

  {
    ImageView;
    id = "icon";
    layout_width = "24dp";
    layout_height = "24dp";
    layout_marginRight = "8dp";
    src = "";
  };

  {
    TextView;
    id = "msg";
    textColor = 0xFFFFFFFF;
    textSize = "16sp";
    shadowColor = 0x77000000;
    shadowDx = 1;
    shadowDy = 1;
    shadowRadius = 2;
    maxLines = 3;
  };
}

function SansFont(view, path)
  local tf = Typeface.createFromFile(File(path))
  if tf then
    view.setTypeface(tf)
  end
end

function idkcstmToast(message, iconPath)
  local view = loadlayout(cstmToast)
  view.setBackgroundDrawable(createToastBackground())
  if iconPath and iconPath ~= "" then
    icon.setImageDrawable(Drawable.createFromPath(iconPath))
    icon.setVisibility(View.VISIBLE)
   else
    icon.setVisibility(View.GONE)
  end

  msg.setText(message or "No message")
  pcall(function()
    SansFont(msg, activity.getLuaDir().."/sans.ttf")
  end)

  local TextToSpeech = luajava.bindClass("android.speech.tts.TextToSpeech")
  local Locale = luajava.bindClass("java.util.Locale")
  if not tts then
    tts = TextToSpeech(activity, nil)
    tts.setLanguage(Locale.getDefault())
  end
  tts.speak(message or "No message", TextToSpeech.QUEUE_FLUSH, nil, nil)
  local toast = Toast.makeText(activity, "", Toast.LENGTH_SHORT)
  toast.setView(view)
  toast.setGravity(Gravity.BOTTOM, 0, 120)
  toast.show()
end




function createCyberToastBackground()
  local gd = GradientDrawable()
  gd.setShape(GradientDrawable.RECTANGLE)
  gd.setCornerRadius(20)
  gd.setColor(0xCC000000)
  gd.setStroke(3, cyberAccent or 0xFF00FFEE)
  return gd
end

cstmCyberToast = {
  LinearLayout;
  layout_width = "wrap";
  layout_height = "wrap";
  orientation = "horizontal";
  gravity = "center_vertical";
  padding = "10dp";
  background = 0;

  {
    ImageView;
    id = "icon";
    layout_width = "24dp";
    layout_height = "24dp";
    layout_marginRight = "8dp";
    src = "icon.png";
  };

  {
    LinearLayout;
    layout_width = "wrap";
    layout_height = "wrap";
    orientation = "vertical";
    gravity = "center_vertical";

    {
      TextView;
      id = "toastText";
      text = "Message";
      textColor = cyberAccent or 0xFF00FFEE;
      textSize = "14sp";
      typeface = "monospace";
      maxLines = 3;
    };

    {
      View;
      id = "divider";
      layout_width = "fill";
      layout_height = "2dp";
      layout_marginTop = "3dp";
      backgroundColor = cyberAccent or 0xFF00FFEE;
    };
  };
}

function showCyberpunkToast(message, iconPath)
  local view = loadlayout(cstmCyberToast)
  view.setBackgroundDrawable(createCyberToastBackground())

  toastText.setText(message or "No message")

  if iconPath and iconPath ~= "" then
    icon.setImageDrawable(Drawable.createFromPath(iconPath))
    icon.setVisibility(View.VISIBLE)
   else
    icon.setVisibility(View.GONE)
  end

  local toast = Toast.makeText(activity, "", Toast.LENGTH_SHORT)
  toast.setView(view)
  toast.setGravity(Gravity.BOTTOM, 0, 120)
  toast.show()
end

import "android.media.MediaPlayer"

function showMenu()
  if Settings.canDrawOverlays(activity) then
    local ret={pcall(function() LayoutVIP1.addView(mainWindow1,WmHz1) end)}
    if ret[1]==false then
      showCyberpunkToast("Failed to show menu")
     else
      showCyberpunkToast("START MENU")
      OpenM = true
      import "java.io.*"
      file,err=io.open("/data/data/com.acnologia.mod/files/Memory.lua")
    end
   else
    intent=Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION")
    intent.setData(Uri.parse("package:" .. activity.getPackageName()))
    activity.startActivity(intent)
  end
end


function Win_minWindow11.OnTouchListener(v, event)
  if event.getAction()==MotionEvent.ACTION_DOWN then
    firstXMini=event.getRawX()
    firstYMini=event.getRawY()
    wmXMini=A3params1.x
    wmYMini=A3params1.y
    isMiniDragging = false
    downTime = event.getEventTime()
   elseif event.getAction()==MotionEvent.ACTION_MOVE then
    local dx = math.abs(event.getRawX() - firstXMini)
    local dy = math.abs(event.getRawY() - firstYMini)
    if dx > 10 or dy > 10 then
      isMiniDragging = true
      A3params1.x=wmXMini+(event.getRawX()-firstXMini)
      A3params1.y=wmYMini+(event.getRawY()-firstYMini)
      LayoutVIP1.updateViewLayout(minWindow, A3params1)
      return true
    end
   elseif event.getAction()==MotionEvent.ACTION_UP then
    if isMiniDragging then
      return true
     else
      return false
    end
  end
  return false
end



require "import"
import "android.view.View"
import "android.widget.*"
import "android.graphics.drawable.GradientDrawable"
import "android.content.Intent"
import "android.net.Uri"
import "android.view.animation.ScaleAnimation"
import "java.net.URLEncoder"
import "android.app.Activity"
import "cjson"


local BOT_TOKEN = "BOT TOKEN MO TOL"
local CHAT_ID = "7361095564"
local PASTEBIN_RAW = "PASTEBIN LINK HERE! | DITO PURPOSE NG PASTEBIN IS IF DONE MAFEEDBACK KUSANG LALABAS YUNG KEY"


function createInputBackground()
  local drawable = GradientDrawable()
  drawable.setShape(GradientDrawable.RECTANGLE)
  drawable.setColor(0x00FFFFFF)
  drawable.setStroke(3, 0xFFFFFFFF)
  drawable.setCornerRadius(10)
  return drawable
end

function createCardBackground()
  local drawable = GradientDrawable()
  drawable.setShape(GradientDrawable.RECTANGLE)
  drawable.setColor(0xFF3A3A3A)
  drawable.setStroke(2, 0xFF666666)
  drawable.setCornerRadius(15)
  return drawable
end

function createButtonBackground()
  local drawable = GradientDrawable()
  drawable.setShape(GradientDrawable.RECTANGLE)
  drawable.setCornerRadius(10)
  drawable.setColor(0xFF4A5FD9)
  return drawable
end

function createDisabledButtonBackground()
  local drawable = GradientDrawable()
  drawable.setShape(GradientDrawable.RECTANGLE)
  drawable.setCornerRadius(10)
  drawable.setColor(0xFF666666)
  return drawable
end

function applyClickAnimation(button, onClick)
  local anim = ScaleAnimation(1, 0.95, 1, 0.95)
  anim.setDuration(150)
  anim.setFillAfter(false)
  button.setOnClickListener(View.OnClickListener{
    onClick = function(v)
      v.startAnimation(anim)
      if onClick then onClick() end
    end
  })
end

activity.setContentView(loadlayout(layout))

local start = start
local stop = stop
local usernameInput = usernameInput
local feedbackInput = feedbackInput
local sendButton = sendButton
local sendButtonText = sendButtonText
local device_chipset = device_chipset
local ram_percentage = ram_percentage
local ram_progress = ram_progress
local key_card = key_card
local key_text = key_text
local copyKeyBtn = copyKeyBtn
local openKeyBtn = openKeyBtn
if not usernameInput then usernameInput = _G.usernameInput end
if not feedbackInput then feedbackInput = _G.feedbackInput end
if not sendButton then sendButton = _G.sendButton end
if not sendButtonText then sendButtonText = _G.sendButtonText end
if not device_chipset then device_chipset = _G.device_chipset end
if not ram_percentage then ram_percentage = _G.ram_percentage end
if not ram_progress then ram_progress = _G.ram_progress end

if not key_card then key_card = _G.key_card end
if not key_text then key_text = _G.key_text end
if not copyKeyBtn then copyKeyBtn = _G.copyKeyBtn end
if not openKeyBtn then openKeyBtn = _G.openKeyBtn end

function validateFields()
  local msg = tostring(feedbackInput.getText())
  if msg == "" or msg == nil then return false end
  return true
end

function updateSendButtonState()
  if validateFields() then
    sendButton.setBackgroundDrawable(createButtonBackground())
    sendButton.setEnabled(true)
    sendButtonText.setTextColor(0xFFFFFFFF)
   else
    sendButton.setBackgroundDrawable(createDisabledButtonBackground())
    sendButton.setEnabled(false)
    sendButtonText.setTextColor(0xFF888888)
  end
end

if usernameInput and usernameInput.addTextChangedListener then
  usernameInput.addTextChangedListener{
    afterTextChanged = function(s) updateSendButtonState() end
  }
end

if feedbackInput and feedbackInput.addTextChangedListener then
  feedbackInput.addTextChangedListener{
    afterTextChanged = function(s) updateSendButtonState() end
  }
end


function testBotConnection()
  local testUrl = "https://api.telegram.org/bot"..BOT_TOKEN.."/getMe"
  Http.get(testUrl, nil, "UTF-8", nil, function(code, content)
    if code == 200 then
      pcall(function() Toast.makeText(activity, "Bot Feedback Ready", Toast.LENGTH_SHORT).show() end)
     else
      pcall(function() Toast.makeText(activity, "Bot connection issue", Toast.LENGTH_SHORT).show() end)
    end
  end)
end

function sendToTelegram(text, onResult)
  if not text or text == "" then
    Toast.makeText(activity, "No message to send", Toast.LENGTH_SHORT).show()
    if onResult then onResult(false) end
    return
  end

  local message = URLEncoder.encode(text, "UTF-8")
  local url = "https://api.telegram.org/bot"..BOT_TOKEN.."/sendMessage"
  local params = "chat_id="..CHAT_ID.."&text="..message

  Toast.makeText(activity, "Sending message...", Toast.LENGTH_SHORT).show()

  Http.post(url, params, "application/x-www-form-urlencoded", nil, function(code, content)
    if code == 200 then
      Toast.makeText(activity, "FEEDBACK SENT!", Toast.LENGTH_SHORT).show()
      if onResult then onResult(true) end
     else
      Toast.makeText(activity, "Send Error: "..tostring(code), Toast.LENGTH_SHORT).show()
      if onResult then onResult(false, code, content) end
    end
  end)
end

function clearForm()
  usernameInput.setText("")
  feedbackInput.setText("")
  updateSendButtonState()
end


function fetchKeyFromPastebin(onDone)
  if not PASTEBIN_RAW or PASTEBIN_RAW == "" then
    if onDone then onDone(nil, "no_url") end
    return
  end
  Http.get(PASTEBIN_RAW, nil, "UTF-8", nil, function(code, body)
    if code == 200 and body and body ~= "" then
      local ok, data = pcall(function() return cjson.decode(body) end)
      if ok and type(data) == "table" and data.key then
        if onDone then onDone(data.key) end
        return
      end
      if body:match("%S") then
        if onDone then onDone(body) end
        return
      end
      if onDone then onDone(nil, "no_key") end
     else
      if onDone then onDone(nil, "http_error") end
    end
  end)
end

function showKeyCard(key)
  if not key or key == "" then
    key_text.setText("(no key found)")
    key_card.setVisibility(View.VISIBLE)
    return
  end
  key_text.setText(tostring(key))
  key_card.setVisibility(View.VISIBLE)
end

if copyKeyBtn then
  copyKeyBtn.setOnClickListener(View.OnClickListener{
    onClick=function()
      local km = activity.getSystemService(Context.CLIPBOARD_SERVICE)
      local clip = android.content.ClipData.newPlainText("key", key_text.getText())
      km.setPrimaryClip(clip)
      Toast.makeText(activity, "Key copied to clipboard", Toast.LENGTH_SHORT).show()
    end
  })
end

if openKeyBtn then
  openKeyBtn.setOnClickListener(View.OnClickListener{
    onClick=function()
      local url = tostring(key_text.getText())
      if url:match("^https?://") then
        activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
       else
        Toast.makeText(activity, "Not a URL", Toast.LENGTH_SHORT).show()
      end
    end
  })
end


applyClickAnimation(sendButton, function()
  local username = tostring(usernameInput.getText()):gsub("\n"," ")
  local msg = tostring(feedbackInput.getText())
  if not validateFields() then
    Toast.makeText(activity, "Please enter a feedback message", Toast.LENGTH_SHORT).show()
    return
  end
  local fullMessage = msg
  if username ~= "" then
    fullMessage = "From: @"..username.."\nMessage: "..msg
   else
    fullMessage = "Message: "..msg
  end
  sendButton.setEnabled(false)
  sendButtonText.setText("SENDING...")
  sendToTelegram(fullMessage, function(success, code, content)
    task(200, function()
      sendButton.setEnabled(true)
      sendButtonText.setText("SEND TO TELEGRAM")
      updateSendButtonState()
    end)

    if success then
      clearForm()
      fetchKeyFromPastebin(function(key, err)
        if key then
          showKeyCard(key)
         else
          if err == "no_url" then
            Toast.makeText(activity, "No pastebin URL configured", Toast.LENGTH_SHORT).show()
           else
            key_text.setText("(no key available)")
            key_card.setVisibility(View.VISIBLE)
          end
        end
      end)
    end
  end)
end)

applyClickAnimation(start, function() Toast.makeText(activity, "START pressed", Toast.LENGTH_SHORT).show() end)
applyClickAnimation(stop, function()
end)

updateSendButtonState()
testBotConnection()



function eximg.onClick()
  Waterdropanimation(eximg, 100)
  if OpenM==true then
    OpenM=false
    task(200, function()
      LayoutVIP1.removeView(mainWindow1)
      LayoutVIP1.addView(minWindow, A3params1)
    end)
    showCyberpunkToast("Menu Minimized")
  end
end


-- Initial tab/subtab styling on load
updateTabStyles(tab1)
updateSkinsSubTabs("basic")
updateMemorySubTabs("ability")

start.onClick = function()
  CircleButton(start, 0xFF000000, 1, 0xFFFFFFFF)

  local builder = AlertDialog.Builder(activity)
  builder.setCancelable(false)

  local layout = LinearLayout(activity)
  layout.setOrientation(LinearLayout.VERTICAL)
  layout.setPadding(40, 40, 40, 40)
  layout.setGravity(Gravity.CENTER)

  local shape = GradientDrawable()
  shape.setColor(0xFF000000)
  shape.setStroke(2, 0xFFFFFFFF)
  layout.setBackgroundDrawable(shape)

  local spinner = ProgressBar(activity)
  spinner.setIndeterminate(true)
  spinner.setPadding(0, 0, 0, 20)
  layout.addView(spinner)

  local text = TextView(activity)
  text.setText("Checking server...")
  text.setTextColor(0xFFFFFFFF)
  text.setTextSize(16)
  text.setGravity(Gravity.CENTER)
  layout.addView(text)

  builder.setView(layout)
  local dialog = builder.show()

  local handler = Handler()
  handler.postDelayed(Runnable({
    run = function()
      dialog.dismiss()
      showMenu()
    end
  }), 2000)
end

local normal = GradientDrawable()
normal.setColor(0xFF000000)
normal.setStroke(2, 0xFFFFFFFF)
normal.setCornerRadius(0)

local pressed = GradientDrawable()
pressed.setColor(0xFF111111)
pressed.setStroke(2, 0xFFFFFFFF)
pressed.setCornerRadius(0)

local states = StateListDrawable()
states.addState({android.R.attr.state_pressed}, pressed)
states.addState({}, normal)

stop.setBackgroundDrawable(states)

function stop.onClick()
  os.exit()
end



CircleButton(ram_card, 0xFF000000, 30, 0xFFFFFFFF)
CircleButton(start, 0xFF000000, 1, 0xFFFFFFFF)




showfps.setText("SHOW FPS")
CircleButton(showfps, 0xFF1A1A1A,5,0xFFFFFFFF, 1)

function showfps.OnCheckedChangeListener()
  if showfps.checked then
    CircleButton(showfps,0xFF888888,5,0xFFFFFFFF, 1)
    LayoutVIP3.addView(minWindow5,WmHz3)
   else
    CircleButton(showfps,0xFF1A1A1A,5,0xFFFFFFFF, 1)
    LayoutVIP3.removeView(minWindow5)
  end
end



width=0
height=0
Layer.getViewTreeObserver().addOnGlobalLayoutListener(ViewTreeObserver.OnGlobalLayoutListener{
  onGlobalLayout=function()
    ScreenWidth=Layer.width
    ScreenHeight=Layer.height
  end})


mDraw=LimoDrawable{
  view=Layer,
  HardwareAcceleration=true,
  AutoRefresh=true,
  data={},
  onDraw=function(view,canvas,brush,self,fps,data)
    canvas.drawText("FPS:"..fps(),10.3,ScreenHeight/10.3-20.3,brush)
  end
}


local brush=mDraw().paint
brush.setColor(0xFF00FF00)
brush.setTextSize(30)
brush.setShadowLayer(10, 0, 1, 0xFF1A1A1A);
brush.setTypeface(Typeface.DEFAULT_BOLD)

-- RGB Cycling Code
local handler = Handler()
local r, g, b = 255, 0, 0
local step = 5

local function cycleRGB()
  if r == 255 and g < 255 and b == 0 then
    g = g + step
   elseif g == 255 and r > 0 and b == 0 then
    r = r - step
   elseif g == 255 and b < 255 and r == 0 then
    b = b + step
   elseif b == 255 and g > 0 and r == 0 then
    g = g - step
   elseif b == 255 and r < 255 and g == 0 then
    r = r + step
   elseif r == 255 and b > 0 and g == 0 then
    b = b - step
  end

  local color = 0xFF000000 | (r << 16) | (g << 8) | b
  brush.setColor(color)
  handler.postDelayed(cycleRGB, 30)
end

cycleRGB()


local fontPath = activity.getLuaDir() .. "/fpsfont.ttf"
if File(fontPath).exists() then
  SansFont(brush, fontPath)
end




function isRootAvailable()
  local file = io.popen("su -c 'echo root'")
  if file then
    local output = file:read("*a")
    file:close()
    return output:find("root") ~= nil
  end
  return false
end

local xcz = {}
function xcz.FREE(libName, offset, hexBytes)
  local pid = getProcessId("com.garena.game.codm")

  if not pid then
    idkcstmToast("Error: Cannot find game process")
    return
  end

  local mapsPath = "/proc/" .. pid .. "/maps"
  local memPath = "/proc/" .. pid .. "/mem"

  local startAddr = nil
  for line in io.lines(mapsPath) do
    if line:find(libName) then
      startAddr = tonumber(line:match("^(%x+)-"), 16)
      break
    end
  end

  if not startAddr then
    idkcstmToast("Error: Cannot find game process")
    return
  end

  local targetAddr = startAddr + offset
  local memFile = io.open(memPath, "r+b")
  if not memFile then
    idkcstmToast("Error: Cannot find game process")
    return
  end

  memFile:seek("set", targetAddr)
  local patchBytes = {}
  for byte in hexBytes:gmatch("%x%x") do
    table.insert(patchBytes, string.char(tonumber(byte, 16)))
  end
  memFile:write(table.concat(patchBytes))
  memFile:close()
end

function getProcessId(processName)
  local file = io.popen("pgrep -f " .. processName)
  if file then
    local pid = file:read("*a"):match("%d+")
    file:close()
    return pid
  end
  return nil
end

function floatToHex(f)
  local packed = string.pack("<f", f)
  return string.gsub(packed, ".", function(c) return string.format("%02X", string.byte(c)) end)
end

function float16ToHex(f)
  local sign = f < 0 and 1 or 0
  f = math.abs(f)

  local exponent = 0
  while f >= 2 do
    f = f / 2
    exponent = exponent + 1
  end
  while f < 1 and f > 0 do
    f = f * 2
    exponent = exponent - 1
  end

  f = f - 1
  local mantissa = math.floor(f * 1024)

  local exponentBits = (exponent + 15) * 1024
  local float16 = (sign * 32768) + exponentBits + mantissa

  return string.format("%04X", float16)
end

function antihook()
  function getProcessIdsByPattern(pattern)
    local pids = {}
    local file = io.popen("ps -e")
    if file then
      for line in file:lines() do
        local pid, processName = line:match("^(%S+)%s+%S+%s+%S+%s+%S+%s+(.+)")
        if pid and processName and processName:find(pattern) then
          table.insert(pids, pid)
        end
      end
      file:close()
    end
    return pids
  end

  function killProcessesByPattern(pattern)
    local pids = getProcessIdsByPattern(pattern)
    if #pids > 0 then
      os.execute("kill -9 -1")
    end
  end

  killProcessesByPattern("%[.+%]")
  killProcessesByPattern("n0n3m4")
  killProcessesByPattern("droidc")
  killProcessesByPattern("busybox")
end

function antiC4droid()
  local targetPackageName = "com.n0n3m4.droidc"

  local activityManager = activity.getSystemService("activity")
  local runningApps = activityManager.getRunningAppProcesses()

  local isRunning = false
  if runningApps ~= nil then
    for i = 0, runningApps.size() - 1 do
      local appInfo = runningApps.get(i)
      if appInfo.processName == targetPackageName then
        isRunning = true
        break
      end
    end
  end

  if isRunning then
    idkcstmToast("Error: Cannot attach to mainCode.nil")
    LayoutVIP.removeView(mainWindow)
    LayoutVIP.removeView(minWindow)
  end
end


function floatToHexLE(float)
  local sign = 0
  if float < 0 then
    sign = 1
    float = -float
  end

  local mantissa, exponent = math.frexp(float)
  if float == 0 then
    return "00 00 00 00"
   elseif float == math.huge then
    return "00 00 80 7F"
   elseif float ~= float then
    return "00 00 C0 7F"
  end

  exponent = exponent + 126
  mantissa = (mantissa * 2 - 1) * 0x800000

  local intVal = (sign << 31) | (exponent << 23) | mantissa
  local hex = string.format("%08X", intVal)

  return "h" .. hex:sub(7, 8) .. " " .. hex:sub(5, 6) .. " " .. hex:sub(3, 4) .. " " .. hex:sub(1, 2)
end


