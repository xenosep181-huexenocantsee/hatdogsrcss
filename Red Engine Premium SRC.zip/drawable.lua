function FPS(num)
  if not fps_tab then
    fps_tab = {[num] = {fps=0, lastTime=Date().time, frameCount=0}}
  end
  if not fps_tab[num] then
    fps_tab[num] = {fps=0, lastTime=Date().time, frameCount=0}
  end
  local obj = fps_tab[num]
  obj.frameCount = obj.frameCount + 1
  local curTime = Date().time
  if (curTime - obj.lastTime > 1000) then
    obj.fps = obj.frameCount
    obj.frameCount = 0
    obj.lastTime = curTime
  end
  return obj.fps
end

function DrawFPSOverlay(canvas, fps)
  local text = "FPS: " .. tostring(fps)
  local padX = 18
  local padY = 10
  local textSz = 28
  local accentH = 3
  local cornerR = 6
  local bgPaint = Paint()
  bgPaint.setAntiAlias(true)
  bgPaint.setColor(0xCC000000) 
  bgPaint.setStyle(Paint.Style.FILL)
  local textPaint = Paint()
  textPaint.setAntiAlias(true)
  textPaint.setColor(0xFFFFFFFF) 
  textPaint.setTextSize(textSz)
  textPaint.setTypeface(Typeface.create("monospace", Typeface.BOLD))
  local accentPaint = Paint()
  accentPaint.setAntiAlias(true)
  accentPaint.setColor(0xFFFF6600) 
  accentPaint.setStyle(Paint.Style.FILL)
  local bounds = Rect()
  textPaint.getTextBounds(text, 0, #text, bounds)
  local tw = bounds.width()
  local th = bounds.height()
  local x1 = 16
  local y1 = 16
  local x2 = x1 + tw + padX * 2
  local y2 = y1 + th + padY * 2 + accentH
  local rectF = RectF(x1, y1, x2, y2)
  canvas.drawRoundRect(rectF, cornerR, cornerR, bgPaint)
  canvas.drawText(
  text,
  x1 + padX,
  y1 + padY + th,
  textPaint
  )
  local accentRect = RectF(x1, y2 - accentH, x2, y2)
  canvas.drawRoundRect(accentRect, cornerR, cornerR, accentPaint)
end

function LimoDrawable(callback)
  if not callback.data then
    callback.data = {}
  end
  if callback.HardwareAcceleration == false then
    callback.view.setLayerType(1, nil)
  end
  local Fps = function() return FPS(string.format("%p", callback)) end
  local draw
  if callback.AutoRefresh ~= false then
    draw = function(a, b, c)
      callback.onDraw(callback.view, a, b, c, Fps, callback.data)
      -- Draw FPS overlay on top
      DrawFPSOverlay(a, Fps())
      c.invalidateSelf()
    end
   else
    draw = function(a, b, c)
      callback.onDraw(callback.view, a, b, c, Fps, callback.data)
      DrawFPSOverlay(a, Fps())
    end
  end
  local drawble = LuaDrawable(draw)
  callback.view.post(Runnable{
    run = function() callback.view.setBackground(drawble) end
  })
  return setmetatable(
  {data = callback.data, Refresh = function() drawble.invalidateSelf() end},
  {
    __call = function() return drawble end,
    __tostring = function() return "\ndraw: " .. string.format("%p", callback) end
  }
  )
end