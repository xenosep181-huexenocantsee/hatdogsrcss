require "import"
import "res/init"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"
import "android.content.*"
import "android.graphics.Typeface"
import "android.graphics.Paint"
import "android.net.*"
import "android.provider.Settings"
import "android.content.Context"
import "android.view.animation.*"
import "android.content.pm.ActivityInfo"
import "AndLua"
import "http"
import "layout"
import "java.io.File"
import "android.net.Uri"
import "fpsmeter"
import "drawable"
import "android.graphics.Bitmap"
import "android.graphics.Canvas"
import "android.graphics.Path"
import "android.graphics.drawable.StateListDrawable"
import "android.widget.Toast"
import "android.graphics.drawable.BitmapDrawable"
import "android.view.Gravity"
import "android.graphics.drawable.GradientDrawable"
import "android.graphics.drawable.Drawable"

activity.setTheme(R.AndLua1)
activity.setContentView(loadlayout(layout))
activity.actionBar.hide()
activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS).setStatusBarColor(0xFF000000);

activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE)


cyberAccent = 0xFFFFFFFF
cyberPurple = 0xFFAA00FF
cyberCyan = 0xFF00D9FF

currentTabIndex = 1


local size
local bmpAura, canvasAura
local auraPaint, textPaint
local angle = 0
local running = true
local circleText = "RED ENGINE"

function init(s)
  size = s
  bmpAura = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
  canvasAura = Canvas(bmpAura)
  auraPaint = Paint()
  auraPaint.setAntiAlias(true)
  auraPaint.setStyle(Paint.Style.STROKE)
  auraPaint.setStrokeWidth(3)
  auraPaint.setColor(0xFFFF0000)
  textPaint = Paint()
  textPaint.setAntiAlias(true)
  textPaint.setColor(0xFFFFFFFF)
  textPaint.setTextSize(size * 0.1)
  textPaint.setTextAlign(Paint.Align.CENTER)
  textPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD))
end

function drawAura()
  canvasAura.drawColor(0x00000000, PorterDuff.Mode.CLEAR)

  local cx = size / 2
  local cy = size / 2
  local radius = size * 0.35
  for i = 1, 14 do
    local start = math.rad(angle + i * 25)
    local path = Path()
    for j = 0, 6 do
      local offset = (math.random() - 0.5) * 12
      local r = radius + offset
      local a = start + j * 0.15
      local x = cx + math.cos(a) * r
      local y = cy + math.sin(a) * r
      if j == 0 then
        path.moveTo(x, y)
       else
        path.lineTo(x, y)
      end
    end
    auraPaint.setAlpha(200)
    canvasAura.drawPath(path, auraPaint)
  end
  canvasAura.save()
  canvasAura.rotate(angle, cx, cy)
  for i = 1, 3 do
    local offsetX = (math.random() - 0.5) * 3
    local offsetY = (math.random() - 0.5) * 3
    textPaint.setColor(0xFFFF0000)
    canvasAura.drawText(circleText, cx + offsetX, cy + offsetY + textPaint.getTextSize()/2, textPaint)
  end
  textPaint.setColor(0xFFFFFFFF)
  canvasAura.drawText(circleText, cx, cy + textPaint.getTextSize()/2, textPaint)
  canvasAura.restore()
  aura.setImageBitmap(bmpAura)
  angle = (angle + 1) % 360
end

local function makeTabPage(pageId, leftTitle, rightTitle, leftSwitches, rightSwitches, visible)
  return {
    LinearLayout;
    orientation = "horizontal";
    layout_width = "fill";
    layout_height = "fill";
    padding = "10dp";
    id = pageId;
    visibility = visible and "visible" or "gone";
    {
      CardView;
      layout_width = "0dp";
      layout_weight = "1";
      layout_height = "fill";
      backgroundColor = "0xBB13112A";
      cardElevation = "0dp";
      radius = "6dp";
      layout_marginRight = "6dp";
      id = pageId .. "_lcard";
      {
        ScrollView;
        layout_width = "fill";
        layout_height = "fill";
        {
          LinearLayout;
          orientation = "vertical";
          layout_width = "fill";
          layout_height = "wrap";
          padding = "12dp";
          {
            TextView;
            text = leftTitle;
            textColor = "0xFF9900FF";
            textSize = "10sp";
            Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
            layout_marginBottom = "8dp";
            layout_width = "fill";
            layout_height = "wrap";
            gravity = "center";
          };
          table.unpack(leftSwitches);
        };
      };
    };
    {
      CardView;
      layout_width = "0dp";
      layout_weight = "1";
      layout_height = "fill";
      backgroundColor = "0xBB13112A";
      cardElevation = "0dp";
      radius = "6dp";
      layout_marginLeft = "6dp";
      id = pageId .. "_rcard";
      {
        ScrollView;
        layout_width = "fill";
        layout_height = "fill";
        {
          LinearLayout;
          orientation = "vertical";
          layout_width = "fill";
          layout_height = "wrap";
          padding = "12dp";
          {
            TextView;
            text = rightTitle;
            textColor = "0xFF9900FF";
            textSize = "10sp";
            Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
            layout_marginBottom = "8dp";
            layout_width = "fill";
            layout_height = "wrap";
            gravity = "center";
          };
          table.unpack(rightSwitches);
        };
      };
    };
  }
end

local function sw(id, label)
  return {
    Switch;
    text = label;
    textColor = "0xFFCCCCCC";
    id = id;
    textSize = "11sp";
    Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
    layout_width = "fill";
    layout_height = "wrap";
    layout_marginBottom = "6dp";
  }
end


local function cb(id, label)
  return {
    CheckBox;
    text = label;
    textColor = "0xFFCCCCCC";
    id = id;
    textSize = "11sp";
    Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
    layout_width = "fill";
    layout_height = "wrap";
    layout_marginBottom = "6dp";
    paddingLeft = "16dp";
    gravity = "center_vertical";
  }
end


local function tabBtnV(tabId, iconId, textId, iconSrc, labelText)
  return {
    LinearLayout;
    orientation = "horizontal";
    layout_width = "fill";
    layout_height = "30dp";
    gravity = "center_vertical";
    id = tabId;
    paddingLeft = "10dp";
    paddingRight = "6dp";
    layout_marginBottom = "2dp";
    {
      ImageView;
      layout_width = "18dp";
      layout_height = "18dp";
      src = iconSrc;
      id = iconId;
      colorFilter = "0xFF5A5A7A";
      layout_gravity = "center_vertical";
    };
    {
      TextView;
      text = labelText;
      textColor = "0xFF5A5A7A";
      textSize = "9sp";
      Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
      id = textId;
      layout_marginLeft = "8dp";
      layout_width = "0dp";
      layout_weight = "1";
      layout_height = "wrap";
      layout_gravity = "center_vertical";
    };
  }
end


layout2 = {
  LinearLayout;
  layout_height = "wrap";
  layout_width = "wrap";
  id = "SevMenu";
  {
    CardView;
    layout_height = "wrap";
    layout_width = "wrap";
    backgroundColor = "0xFF12102A";
    cardElevation = "16dp";
    radius = "10dp";
    id = "menu";
    {
      FrameLayout;
      layout_height = "330dp";
      layout_width = "500dp";
      {
        ImageView;
        id = "particleView";
        layout_width = "fill";
        layout_height = "fill";
        scaleType = "FIT_XY";
      };
      {
        LinearLayout;
        layout_height = "fill";
        layout_width = "fill";
        orientation = "horizontal";
        {
          LinearLayout;
          layout_width = "115dp";
          layout_height = "330dp";
          orientation = "vertical";
          backgroundColor = "0xCC0D0B22";
          gravity = "center_horizontal";
          paddingTop = "8dp";
          paddingBottom = "4dp";
          {
            ImageView;
            layout_width = "150dp";
            layout_height = "100dp";
            id = "aura";
            scaleType = "fitCenter";
            layout_gravity = "center_horizontal";
            layout_marginBottom = "4dp";
          };
          {
            View;
            layout_width = "fill";
            layout_height = "2dp";
            backgroundColor = "0xFF8000FF";
            layout_marginBottom = "6dp";
          };
          tabBtnV("tab1","tab1icon","tab1text","img/Information.png","INFORMATION");
          tabBtnV("tab2","tab2icon","tab2text","img/Visuals.png","VISUAL");
          tabBtnV("tab3","tab3icon","tab3text","img/Memory.png","MEMORY");
          tabBtnV("tab4","tab4icon","tab4text","img/Misc.png","MISC");
          tabBtnV("tab5","tab5icon","tab5text","img/Skins.png","SKINS");
          tabBtnV("tab6","tab6icon","tab6text","img/Settings.png","SETTINGS");
        };
        {
          View;
          layout_width = "1dp";
          layout_height = "fill";
          backgroundColor = "0xFF2A1A50";
        };
        {
          LinearLayout;
          layout_width = "0dp";
          layout_weight = "1";
          layout_height = "fill";
          orientation = "vertical";
          {
            LinearLayout;
            orientation = "horizontal";
            layout_width = "fill";
            layout_height = "46dp";
            backgroundColor = "0xCC0A0820";
            gravity = "center_vertical";
            paddingLeft = "14dp";
            paddingRight = "10dp";
            id = "headertop";
            {
              TextView;
              text = "RED";
              textColor = "0xFFFFFFFF";
              textSize = "13sp";
              Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
              layout_width = "wrap";
              layout_height = "wrap";
              id = "tit2";
            };
            {
              TextView;
              text = "ENGINE PREMIUM DELUXE";
              textColor = "0xFF9900FF";
              textSize = "13sp";
              Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
              layout_width = "0dp";
              layout_weight = "1";
              layout_height = "wrap";
              id = "tit3";
            };
            {
              TextView;
              text = "FPS: 60";
              textColor = "0xFFFF4444";
              textSize = "10sp";
              Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
              id = "fps_display";
              layout_width = "wrap";
              layout_height = "wrap";
            };
          };
          {
            View;
            layout_width = "fill";
            layout_height = "2dp";
            backgroundColor = "0xFF7700CC";
          };
          {
            FrameLayout;
            layout_width = "fill";
            layout_height = "0dp";
            layout_weight = "1";
            {
              LinearLayout;
              orientation = "horizontal";
              layout_width = "fill";
              layout_height = "fill";
              padding = "8dp";
              id = "page_info";
              visibility = "visible";
              {
                CardView;
                layout_width = "0dp";
                layout_weight = "1";
                layout_height = "fill";
                backgroundColor = "0xBB13112A";
                cardElevation = "0dp";
                radius = "6dp";
                layout_marginRight = "5dp";
                id = "info_card1";
                {
                  ScrollView;
                  layout_width = "fill";
                  layout_height = "fill";
                  {
                    LinearLayout;
                    orientation = "vertical";
                    layout_width = "fill";
                    layout_height = "wrap";
                    padding = "14dp";
                    gravity = "center_horizontal";
                    {
                      TextView;
                      text = "DEVELOPER INFO";
                      textColor = "0xFF9900FF";
                      textSize = "10sp";
                      Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                      layout_marginBottom = "12dp";
                      layout_width = "fill";
                      layout_height = "wrap";
                      gravity = "center";
                    };
                    {
                      TextView;
                      text = "Developer : Sev";
                      textColor = "0xFFFFFFFF";
                      textSize = "13sp";
                      Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                      layout_marginBottom = "4dp";
                      layout_width = "fill";
                      layout_height = "wrap";
                      gravity = "center";
                    };
                    {
                      TextView;
                      text = "Red Engine";
                      textColor = "0xFF8A9AB0";
                      textSize = "11sp";
                      layout_width = "fill";
                      layout_height = "wrap";
                      layout_marginBottom = "6dp";
                      gravity = "center";
                    };
                    {
                      TextView;
                      text = "V3 | Sev$hit";
                      textColor = "0xFF9900FF";
                      textSize = "11sp";
                      Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                      layout_width = "fill";
                      layout_height = "wrap";
                      gravity = "center";
                    };
                  };
                };
              };
              {
                CardView;
                layout_width = "0dp";
                layout_weight = "1";
                layout_height = "fill";
                backgroundColor = "0xBB13112A";
                cardElevation = "0dp";
                radius = "6dp";
                layout_marginLeft = "5dp";
                id = "ram_card";
                {
                  ScrollView;
                  layout_width = "fill";
                  layout_height = "fill";
                  {
                    LinearLayout;
                    orientation = "vertical";
                    layout_width = "fill";
                    layout_height = "wrap";
                    padding = "12dp";
                    {
                      TextView;
                      text = "DEVICE INFO";
                      textColor = "0xFF9900FF";
                      textSize = "10sp";
                      Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                      layout_marginBottom = "8dp";
                      layout_width = "fill";
                      layout_height = "wrap";
                      gravity = "center";
                    };
                    {
                      TextView;
                      text = "Chipset:";
                      textColor = "0xFF8A9AB0";
                      textSize = "10sp";
                      layout_width = "fill";
                      layout_height = "wrap";
                    };
                    {
                      TextView;
                      text = "Loading...";
                      textColor = "0xFFFFFFFF";
                      textSize = "10sp";
                      id = "device_chipset";
                      layout_width = "fill";
                      layout_height = "wrap";
                      layout_marginBottom = "8dp";
                    };
                    {
                      LinearLayout;
                      orientation = "horizontal";
                      layout_width = "fill";
                      layout_height = "wrap";
                      layout_marginBottom = "4dp";
                      {
                        TextView;
                        text = "RAM: ";
                        textColor = "0xFF8A9AB0";
                        textSize = "11sp";
                        layout_width = "wrap";
                        layout_height = "wrap";
                      };
                      {
                        TextView;
                        text = "0%";
                        textColor = "0xFF4CAF50";
                        textSize = "11sp";
                        Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                        id = "ram_percentage";
                        layout_width = "wrap";
                        layout_height = "wrap";
                      };
                    };
                    {
                      ProgressBar;
                      layout_width = "fill";
                      layout_height = "wrap";
                      max = 100;
                      progress = 0;
                      id = "ram_progress";
                      layout_marginBottom = "6dp";
                      style = "?android:attr/progressBarStyleHorizontal";
                    };
                    {
                      LinearLayout;
                      orientation = "horizontal";
                      layout_width = "fill";
                      layout_height = "wrap";
                      {
                        TextView;
                        text = "Used: ";
                        textColor = "0xFF8A9AB0";
                        textSize = "10sp";
                        layout_width = "wrap";
                        layout_height = "wrap";
                      };
                      {
                        TextView;
                        text = "--";
                        textColor = "0xFFCCCCCC";
                        textSize = "10sp";
                        id = "ram_used";
                        layout_width = "wrap";
                        layout_height = "wrap";
                      };
                    };
                  };
                };
              };
            };
            {
              LinearLayout;
              orientation = "horizontal";
              layout_width = "fill";
              layout_height = "fill";
              padding = "8dp";
              id = "page_visual";
              visibility = "gone";
              {
                CardView;
                layout_width = "0dp";
                layout_weight = "1";
                layout_height = "fill";
                backgroundColor = "0xBB13112A";
                cardElevation = "0dp";
                radius = "6dp";
                layout_marginRight = "5dp";
                id = "visualcard1";
                {
                  ScrollView;
                  layout_width = "fill";
                  layout_height = "fill";
                  {
                    LinearLayout;
                    orientation = "vertical";
                    layout_width = "fill";
                    layout_height = "wrap";
                    padding = "10dp";
                    {
                      TextView;
                      text = "VISUAL ESP MAIN";
                      textColor = "0xFF9900FF";
                      textSize = "10sp";
                      Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                      layout_width = "fill";
                      layout_height = "wrap";
                      gravity = "center";
                      layout_marginBottom = "8dp";
                      id = "visualtext1";
                    };
                    sw("ybwall", "WallHack Yellow/Blue");
                    sw("ybred", "WallHack Red");
                    sw("brtags", "BR Tags");
                  };
                };
              };
              {
                CardView;
                layout_width = "0dp";
                layout_weight = "1";
                layout_height = "fill";
                backgroundColor = "0xBB13112A";
                cardElevation = "0dp";
                radius = "6dp";
                layout_marginLeft = "5dp";
                id = "visualcard2";
                {
                  ScrollView;
                  layout_width = "fill";
                  layout_height = "fill";
                  {
                    LinearLayout;
                    orientation = "vertical";
                    layout_width = "fill";
                    layout_height = "wrap";
                    padding = "10dp";
                    {
                      TextView;
                      text = "VISUAL ESP OTHERS";
                      textColor = "0xFF9900FF";
                      textSize = "10sp";
                      Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                      layout_width = "fill";
                      layout_height = "wrap";
                      gravity = "center";
                      layout_marginBottom = "8dp";
                      id = "visualtext2";
                    };
                    sw("antenna", "Antenna Red");
                    sw("antenna1", "Antenna Cyan");
                    sw("antenna2", "Antenna Black");
                  };
                };
              };
            };
            {
              LinearLayout;
              orientation = "horizontal";
              layout_width = "fill";
              layout_height = "fill";
              padding = "8dp";
              id = "page_memory";
              visibility = "gone";
              {
                CardView;
                layout_width = "0dp";
                layout_weight = "1";
                layout_height = "fill";
                backgroundColor = "0xBB13112A";
                cardElevation = "0dp";
                radius = "6dp";
                layout_marginRight = "5dp";
                id = "memory_card1";
                {
                  ScrollView;
                  layout_width = "fill";
                  layout_height = "fill";
                  {
                    LinearLayout;
                    orientation = "vertical";
                    layout_width = "fill";
                    layout_height = "wrap";
                    padding = "10dp";
                    {
                      TextView;
                      text = "MEMORY MAIN";
                      textColor = "0xFF9900FF";
                      textSize = "10sp";
                      Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                      layout_width = "fill";
                      layout_height = "wrap";
                      gravity = "center";
                      layout_marginBottom = "8dp";
                    };
                    sw("Nspread", "No Spread");
                    sw("Nrecoil", "No Recoil");
                    sw("Nreload", "No Recoil");
                  };
                };
              };
              {
                CardView;
                layout_width = "0dp";
                layout_weight = "1";
                layout_height = "fill";
                backgroundColor = "0xBB13112A";
                cardElevation = "0dp";
                radius = "6dp";
                layout_marginLeft = "5dp";
                id = "memory_card2";
                {
                  ScrollView;
                  layout_width = "fill";
                  layout_height = "fill";
                  {
                    LinearLayout;
                    orientation = "vertical";
                    layout_width = "fill";
                    layout_height = "wrap";
                    padding = "10dp";
                    {
                      TextView;
                      text = "MEMORY SETTINGS";
                      textColor = "0xFF9900FF";
                      textSize = "10sp";
                      Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                      layout_width = "fill";
                      layout_height = "wrap";
                      gravity = "center";
                      layout_marginBottom = "8dp";
                    };
                    sw("fscope", "Fast Scope");
                    sw("fswitch", "Fast Switch");
                    sw("buff", "Buff Damage");
                    sw("hitbox", "HITBOX (risky)");
                  };
                };
              };
            };
            {
              LinearLayout;
              orientation = "horizontal";
              layout_width = "fill";
              layout_height = "fill";
              padding = "8dp";
              id = "page_misc";
              visibility = "gone";
              {
                CardView;
                layout_width = "0dp";
                layout_weight = "1";
                layout_height = "fill";
                backgroundColor = "0xBB13112A";
                cardElevation = "0dp";
                radius = "6dp";
                layout_marginRight = "5dp";
                id = "misc_card1";
                {
                  ScrollView;
                  layout_width = "fill";
                  layout_height = "fill";
                  {
                    LinearLayout;
                    orientation = "vertical";
                    layout_width = "fill";
                    layout_height = "wrap";
                    padding = "10dp";
                    {
                      TextView;
                      text = "MISC MAIN";
                      textColor = "0xFF9900FF";
                      textSize = "10sp";
                      Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                      layout_width = "fill";
                      layout_height = "wrap";
                      gravity = "center";
                      layout_marginBottom = "8dp";
                    };
                    sw("Ncrouch", "No Crouch");
                    sw("speed", "Normal Speed Hack");
                  };
                };
              };
              {
                CardView;
                layout_width = "0dp";
                layout_weight = "1";
                layout_height = "fill";
                backgroundColor = "0xBB13112A";
                cardElevation = "0dp";
                radius = "6dp";
                layout_marginLeft = "5dp";
                id = "misc_card2";
                {
                  ScrollView;
                  layout_width = "fill";
                  layout_height = "fill";
                  {
                    LinearLayout;
                    orientation = "vertical";
                    layout_width = "fill";
                    layout_height = "wrap";
                    padding = "10dp";
                    {
                      TextView;
                      text = "MISC ABILITY";
                      textColor = "0xFF9900FF";
                      textSize = "10sp";
                      Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                      layout_width = "fill";
                      layout_height = "wrap";
                      gravity = "center";
                      layout_marginBottom = "8dp";
                    };
                    sw("Parachute", "No Parachute");
                    sw("wing", "No Wingsuit");
                    sw("kinetic", "Kinetic Armor");
                  };
                };
              };
            };
            {
              LinearLayout;
              orientation = "horizontal";
              layout_width = "fill";
              layout_height = "fill";
              padding = "8dp";
              id = "page_skins";
              visibility = "gone";
              {
                CardView;
                layout_width = "0dp";
                layout_weight = "1";
                layout_height = "fill";
                backgroundColor = "0xBB13112A";
                cardElevation = "0dp";
                radius = "6dp";
                layout_marginRight = "5dp";
                id = "skins_card1";
                {
                  ScrollView;
                  layout_width = "fill";
                  layout_height = "fill";
                  {
                    LinearLayout;
                    orientation = "vertical";
                    layout_width = "fill";
                    layout_height = "wrap";
                    padding = "10dp";
                    {
                      TextView;
                      text = "GUN SKINS";
                      textColor = "0xFF9900FF";
                      textSize = "10sp";
                      Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                      layout_width = "fill";
                      layout_height = "wrap";
                      gravity = "center";
                      layout_marginBottom = "8dp";
                    };
                    sw("sk1", "AK47 - Radiance");
                    sw("sk2", "M4 - Dark Matter");
                    sw("sk3", "DL Q33 - Lotus");
                  };
                };
              };
              {
                CardView;
                layout_width = "0dp";
                layout_weight = "1";
                layout_height = "fill";
                backgroundColor = "0xBB13112A";
                cardElevation = "0dp";
                radius = "6dp";
                layout_marginLeft = "5dp";
                id = "skins_card2";
                {
                  ScrollView;
                  layout_width = "fill";
                  layout_height = "fill";
                  {
                    LinearLayout;
                    orientation = "vertical";
                    layout_width = "fill";
                    layout_height = "wrap";
                    padding = "10dp";
                    {
                      TextView;
                      text = "OPERATOR SKINS";
                      textColor = "0xFF9900FF";
                      textSize = "10sp";
                      Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                      layout_width = "fill";
                      layout_height = "wrap";
                      gravity = "center";
                      layout_marginBottom = "8dp";
                    };
                    sw("sk4", "Ghost - Obsidian");
                    sw("sk5", "Price - Legend");
                    sw("sk6", "Roze - Phantom");
                  };
                };
              };
            };
            {
              LinearLayout;
              orientation = "horizontal";
              layout_width = "fill";
              layout_height = "fill";
              padding = "8dp";
              id = "page_config";
              visibility = "gone";
              {
                CardView;
                layout_width = "0dp";
                layout_weight = "1";
                layout_height = "fill";
                backgroundColor = "0xBB13112A";
                cardElevation = "0dp";
                radius = "6dp";
                layout_marginRight = "5dp";
                id = "config_card1";
                {
                  ScrollView;
                  layout_width = "fill";
                  layout_height = "fill";
                  {
                    LinearLayout;
                    orientation = "vertical";
                    layout_width = "fill";
                    layout_height = "wrap";
                    padding = "10dp";
                    {
                      TextView;
                      text = "CONFIG MAIN";
                      textColor = "0xFF9900FF";
                      textSize = "10sp";
                      Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                      layout_marginBottom = "8dp";
                      layout_width = "fill";
                      layout_height = "wrap";
                      gravity = "center";
                    };
                    sw("cfg1", "Save Settings");
                    sw("cfg2", "Auto Enable");
                    sw("cfg3", "Stealth Mode");
                  };
                };
              };
              {
                CardView;
                layout_width = "0dp";
                layout_weight = "1";
                layout_height = "fill";
                backgroundColor = "0xBB13112A";
                cardElevation = "0dp";
                radius = "6dp";
                layout_marginLeft = "5dp";
                id = "config_card2";
                {
                  ScrollView;
                  layout_width = "fill";
                  layout_height = "fill";
                  {
                    LinearLayout;
                    orientation = "vertical";
                    layout_width = "fill";
                    layout_height = "wrap";
                    padding = "10dp";
                    {
                      TextView;
                      text = "SYSTEM";
                      textColor = "0xFF9900FF";
                      textSize = "10sp";
                      Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                      layout_marginBottom = "10dp";
                      layout_width = "fill";
                      layout_height = "wrap";
                      gravity = "center";
                    };
                    {
                      ToggleButton;
                      textOff = "SHOW FPS";
                      textOn = "HIDE FPS";
                      textColor = "0xFFFFFFFF";
                      id = "showfps";
                      textSize = "11sp";
                      layout_width = "fill";
                      layout_height = "wrap";
                      layout_marginBottom = "10dp";
                    };
                    {
                      Button;
                      text = "EXIT MENU";
                      textColor = "0xFFFFFFFF";
                      backgroundColor = "0xFF7700CC";
                      id = "exitmenuu";
                      textSize = "12sp";
                      Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
                      layout_width = "fill";
                      layout_height = "45dp";
                    };
                  };
                };
              };
            };
          };
        };
      };
    };
  };
};

------- ICON FOR MENU

minlay2 = {
  LinearLayout;
  layout_width = "120dp";
  layout_height = "wrap";
  id = "jumpmenu";
  orientation = "vertical";
  gravity = "center_horizontal";
  {
    CardView;
    layout_width = "60dp";
    layout_height = "wrap";
    layout_marginBottom = "0dp";
    layout_marginLeft = "20dp";
    cardCornerRadius = "8dp";
    cardBackgroundColor = "0x00000000";
    cardElevation = "4dp";
    {
      TextView;
      id = "fpsLabel";
      layout_width = "wrap";
      layout_height = "wrap";
      text = "FPS : 60:00";
      Typeface = Typeface.defaultFromStyle(Typeface.BOLD);
      textColor = "#00FF41";
      textSize = "9sp";
      paddingTop = "3dp";
      paddingBottom = "3dp";
      paddingLeft = "10dp";
      paddingRight = "10dp";
    };
  };
  {
    FrameLayout;
    layout_width = "75dp";
    layout_height = "75dp";
    {
      View;
      layout_width = "75dp";
      layout_height = "75dp";
      background = {
        shape = "oval";
        solid = { color = "#FFD700" };
      };
    };
    {
      View;
      layout_width = "69dp";
      layout_height = "69dp";
      layout_gravity = "center";
      background = {
        shape = "oval";
        solid = { color = "#0D0D1A" };
      };
    };
    {
      ImageView;
      layout_width = "62dp";
      layout_height = "62dp";
      src = "icon.png";
      id = "Win_minWindow11";
      layout_gravity = "center";
      scaleType = "centerCrop";
      onClick = function()
        Waterdropanimation(Win_minWindow11, 50)
        if OpenM == false then
          OpenM = true
          mainWindow1.setVisibility(View.VISIBLE)
          showCyberpunkToast("Menu Show")
         else
          OpenM = false
          mainWindow1.setVisibility(View.GONE)
          showCyberpunkToast("Menu Hidden")
        end
      end;
    };
  };
};

LayoutVIP1 = activity.getSystemService(Context.WINDOW_SERVICE)
LayoutVIP = activity.getSystemService(Context.WINDOW_SERVICE)
HasFocus = false

WmHz1 = WindowManager.LayoutParams()
if Build.VERSION.SDK_INT >= 26 then
  WmHz1.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
 else
  WmHz1.type = WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
end
import "android.graphics.PixelFormat"
WmHz1.format = PixelFormat.RGBA_8888
WmHz1.flags = WindowManager.LayoutParams().FLAG_NOT_FOCUSABLE
WmHz1.gravity = Gravity.CENTER
WmHz1.x = 0
WmHz1.y = 0
WmHz1.width = WindowManager.LayoutParams.WRAP_CONTENT
WmHz1.height = WindowManager.LayoutParams.WRAP_CONTENT
mainWindow1 = loadlayout(layout2)
mainWindow1.setVisibility(View.GONE)

local outlineGD = GradientDrawable()
outlineGD.setShape(GradientDrawable.RECTANGLE)
outlineGD.setColor(0x00000000)
outlineGD.setStroke(2, 0x00000000)
outlineGD.setCornerRadius(10)
SevMenu.setBackgroundDrawable(outlineGD)


A3params1 = WindowManager.LayoutParams()
if Build.VERSION.SDK_INT >= 26 then
  A3params1.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
 else
  A3params1.type = WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
end
A3params1.format = PixelFormat.RGBA_8888
A3params1.flags = WindowManager.LayoutParams().FLAG_NOT_FOCUSABLE
A3params1.gravity = Gravity.TOP | Gravity.LEFT
A3params1.x = 50
A3params1.y = 100
A3params1.width = WindowManager.LayoutParams.WRAP_CONTENT
A3params1.height = WindowManager.LayoutParams.WRAP_CONTENT
minWindow = loadlayout(minlay2)

OpenM = false
isMax1 = true


LayoutVIP3=activity.getSystemService(Context.WINDOW_SERVICE)
HasFocus=false
WmHz3 =WindowManager.LayoutParams()
if Build.VERSION.SDK_INT >= 26 then WmHz3.type =WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
 else WmHz3.type =WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
end
import "android.graphics.PixelFormat"
WmHz3.format =PixelFormat.RGBA_8888
WmHz3.flags=WindowManager.LayoutParams().FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
WmHz3.gravity = Gravity.CENTER| Gravity.TOP
WmHz3.x = 0
WmHz3.y = 0
minWindow5 = loadlayout(fpsmeter)



function menu.OnTouchListener(v, event)
  if event.getAction() == MotionEvent.ACTION_DOWN then
    firstX = event.getRawX()
    firstY = event.getRawY()
    wmX = WmHz1.x
    wmY = WmHz1.y
   elseif event.getAction() == MotionEvent.ACTION_MOVE then
    WmHz1.x = wmX + (event.getRawX() - firstX)
    WmHz1.y = wmY + (event.getRawY() - firstY)
    LayoutVIP1.updateViewLayout(mainWindow1, WmHz1)
   elseif event.getAction() == MotionEvent.ACTION_UP then
  end
  return true
end


function CircleButtonAsh(view, Grad, Col, radiu, InsideColor1)
  import "android.graphics.drawable.GradientDrawable"
  drawable = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, {Grad, Col})
  drawable.setShape(GradientDrawable.RECTANGLE)
  drawable.setCornerRadii({radiu, radiu, radiu, radiu, radiu, radiu, radiu, radiu})
  drawable.setStroke(2.1, InsideColor1)
  view.setBackgroundDrawable(drawable)
end


function CircleButtonTab(view,InsideColor,radiu,InsideColor1)
  import "android.graphics.drawable.GradientDrawable"
  drawable = GradientDrawable()
  drawable.setShape(GradientDrawable.RECTANGLE)
  drawable.setCornerRadii({radiu, radiu, radiu, radiu, radiu, radiu, radiu, radiu})
  drawable.setColor(InsideColor)
  drawable.setStroke(2, InsideColor1)
  view.setBackgroundDrawable(drawable)
end


function CircleButton(view,InsideColor,radiu,InsideColor1)
  import "android.graphics.drawable.GradientDrawable"
  drawable = GradientDrawable()
  drawable.setShape(GradientDrawable.RECTANGLE)
  drawable.setCornerRadii({radiu, radiu, radiu, radiu, radiu, radiu, radiu, radiu})
  drawable.setColor(InsideColor)
  drawable.setStroke(2, InsideColor1)
  view.setBackgroundDrawable(drawable)
end

function SetBackgroundOutline(view, InsideColor, radius, StrokeColor, StrokeWidth)
  local drawable = GradientDrawable()
  drawable.setShape(GradientDrawable.RECTANGLE)
  drawable.setCornerRadii({radius, radius, radius, radius, radius, radius, radius, radius})
  drawable.setColor(InsideColor)
  drawable.setStroke(StrokeWidth, StrokeColor)
  view.setBackgroundDrawable(drawable)
end




local allCards = {
  info_card1, ram_card,
  visualcard1, visualcard2,
  memory_card1, memory_card2,
  misc_card1, misc_card2,
  skins_card1, skins_card2,
  config_card1, config_card2
}
for _, card in ipairs(allCards) do
  CircleButton(card, 0x00000000, 5, 0xFF330066)
end

CircleButton(visualtext1, 0xFF13112A, 0, 0xFF440088)
CircleButton(visualtext2, 0xFF13112A, 0, 0xFF440088)

CircleButton(menu, 0xFF13112A, 0, 0xFFAA00FF)



local fpsHandler = Handler()
local function updateFPS()
  local fps = math.random(58, 62) + math.random() * 0.99
  fpsLabel.setText(string.format("FPS : %.2f", fps))
  pcall(function() fps_display.setText(string.format("FPS: %.1f", fps)) end)
  fpsHandler.postDelayed(updateFPS, 100)
end
updateFPS()

local allPages = {"page_info","page_visual","page_memory","page_misc","page_skins","page_config"}
local allTabs = {tab1, tab2, tab3, tab4, tab5, tab6}
local allIcons = {tab1icon, tab2icon, tab3icon, tab4icon, tab5icon, tab6icon}
local allTexts = {tab1text, tab2text, tab3text, tab4text, tab5text, tab6text}
local tabNames = {"Information", "Visual", "Memory", "Misc", "Skins", "Settings"}

local COL_ACTIVE_ICON = 0xFFAA00FF -- red icon when active
local COL_INACTIVE_ICON = 0xFF5A5A7A -- dark gray when inactive
local COL_ACTIVE_TEXT = 0xFFFFFFFF -- white text when active
local COL_INACTIVE_TEXT = 0xFF5A5A7A -- gray text when inactive

local function setTabActiveBg(view, active)
  local gd = GradientDrawable()
  gd.setShape(GradientDrawable.RECTANGLE)
  gd.setCornerRadius(6)
  if active then
    gd.setColor(0xFF2A0060)
    gd.setStroke(1, 0xFFAA00FF)
   else
    gd.setColor(0x00000000)
    gd.setStroke(0, 0x00000000)
  end
  view.setBackgroundDrawable(gd)
end

function switchToTab(idx)
  currentTabIndex = idx
  for i = 1, 6 do
    local pg = _G[allPages[i]]
    if pg then pg.setVisibility(View.GONE) end
    if allIcons[i] then allIcons[i].setColorFilter(COL_INACTIVE_ICON) end
    if allTexts[i] then
      allTexts[i].setVisibility(View.VISIBLE)
      allTexts[i].setTextColor(COL_INACTIVE_TEXT)
    end
    if allTabs[i] then setTabActiveBg(allTabs[i], false) end
  end
  local activePg = _G[allPages[idx]]
  if activePg then activePg.setVisibility(View.VISIBLE) end
  if allIcons[idx] then allIcons[idx].setColorFilter(COL_ACTIVE_ICON) end
  if allTexts[idx] then
    allTexts[idx].setVisibility(View.VISIBLE)
    allTexts[idx].setTextColor(COL_ACTIVE_TEXT)
  end
  if allTabs[idx] then setTabActiveBg(allTabs[idx], true) end
end

switchToTab(1)

function tab1.onClick() switchToTab(1) end
function tab2.onClick() switchToTab(2) end
function tab3.onClick() switchToTab(3) end
function tab4.onClick() switchToTab(4) end
function tab5.onClick() switchToTab(5) end
function tab6.onClick() switchToTab(6) end

local COLOR_ON = 0xFFFFC107
local COLOR_OFF = 0xFF333333

function createSimpleTrack(isChecked)
  local gd = GradientDrawable()
  gd.setCornerRadius(20)
  gd.setColor(isChecked and COLOR_ON or COLOR_OFF)
  return gd
end

local switches = {ybwall, ybred, brtags, antenna, antenna1, antenna2, Nspread, Nrecoil, Nreload, speed, Ncrouch, hitbox, buff, Parachute, wing, kinetic, fswitch, fscope}
for i, sw in ipairs(switches) do
  if sw then
    local trackStates = StateListDrawable()
    trackStates.addState({android.R.attr.state_checked}, createSimpleTrack(true))
    trackStates.addState({-android.R.attr.state_checked}, createSimpleTrack(false))
    sw.setTrackDrawable(trackStates)
    local thumb = GradientDrawable()
    thumb.setShape(GradientDrawable.OVAL)
    thumb.setSize(30, 30)
    thumb.setColor(0xFFCCCCCC)
    sw.setThumbDrawable(thumb)
    sw.setOnCheckedChangeListener(function(view, checked)
      local states = StateListDrawable()
      states.addState({android.R.attr.state_checked}, createSimpleTrack(true))
      states.addState({-android.R.attr.state_checked}, createSimpleTrack(false))
      view.setTrackDrawable(states)
    end)
  end
end


local COLOR_ACTIVE = 0xFFCC0000 -- red active
local COLOR_INACTIVE = 0xFF444444 -- grey inactive
local COLOR_TEXT = 0xFFCCCCCC -- light grey text

local checkboxes = {}
for i, cb in ipairs(checkboxes) do
  local function createCheckDrawable(checked)
    local size = 50
    local bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    local canvas = Canvas(bitmap)
    local paint = Paint()
    paint.setAntiAlias(true)
    paint.setStyle(Paint.Style.FILL)
    paint.setColor(checked and COLOR_ACTIVE or 0xFF1F1F1F)
    local path = Path()
    local centerX, centerY = size / 2, size / 2
    local radius = size * 0.4
    for j = 0, 5 do
      local angle = math.rad(60 * j - 30)
      local x = centerX + radius * math.cos(angle)
      local y = centerY + radius * math.sin(angle)
      if j == 0 then
        path.moveTo(x, y)
       else
        path.lineTo(x, y)
      end
    end
    path.close()
    canvas.drawPath(path, paint)
    paint.setStyle(Paint.Style.STROKE)
    paint.setStrokeWidth(3)
    paint.setColor(checked and COLOR_ACTIVE or COLOR_INACTIVE)
    canvas.drawPath(path, paint)
    if checked then
      local icon = Paint()
      icon.setAntiAlias(true)
      icon.setStyle(Paint.Style.STROKE)
      icon.setStrokeWidth(5)
      icon.setStrokeCap(Paint.Cap.ROUND)
      icon.setStrokeJoin(Paint.Join.ROUND)
      icon.setColor(0xFFFFFFFF)
      local checkPath = Path()
      checkPath.moveTo(size * 0.28, size * 0.55)
      checkPath.lineTo(size * 0.45, size * 0.72)
      checkPath.lineTo(size * 0.72, size * 0.32)
      canvas.drawPath(checkPath, icon)
    end

    return BitmapDrawable(activity.getResources(), bitmap)
  end

  cb.setButtonDrawable(createCheckDrawable(cb.isChecked()))
  cb.setOnCheckedChangeListener(function(view, checked)
    view.setButtonDrawable(createCheckDrawable(checked))
  end)
end



function exitmenuu.onClick()
  os.exit()
end


function Waterdropanimation(Controls,time)
  import "android.animation.ObjectAnimator"
  ObjectAnimator().ofFloat(Controls,"scaleX",{1,.8,1.3,.9,1}).setDuration(time).start()
  ObjectAnimator().ofFloat(Controls,"scaleY",{1,.8,1.3,.9,1}).setDuration(time).start()
end

function CircleButton(view,InsideColor,radiu,InsideColor1)
  import "android.graphics.drawable.GradientDrawable"
  drawable = GradientDrawable()
  drawable.setShape(GradientDrawable.RECTANGLE)
  drawable.setCornerRadii({radiu, radiu, radiu, radiu, radiu, radiu, radiu, radiu})
  drawable.setColor(InsideColor)
  drawable.setStroke(2, InsideColor1)
  view.setBackgroundDrawable(drawable)
end


function SansFont(ido, file)
  ido.setTypeface(Typeface.createFromFile(File(file)))
end

local fontPath = activity.getLuaDir() .. "/Font/Title.ttf"
if File(fontPath).exists() then
  SansFont(tit2, fontPath)
  SansFont(tit3, fontPath)
end



function formatMemory(kb)
  if kb < 1024 then
    return string.format("%.2f KB", kb)
  end
  local mb = kb / 1024
  if mb < 1024 then
    return string.format("%.2f MB", mb)
  end
  return string.format("%.2f GB", mb / 1024)
end

function getMemoryInfo()
  local memInfo = {}
  local success, err = pcall(function()
    for line in io.lines("/proc/meminfo") do
      local k, v = line:match("([^:]+):%s+(%d+).+")
      if k and v then
        memInfo[k] = tonumber(v)
      end
    end
  end)

  if not success then
    print("Error reading meminfo: " .. err)
    return nil
  end
  return memInfo
end

function getChipsetInfo()
  local chipset = "Unknown"

  local success, err = pcall(function()
    local f = io.open("/proc/device-tree/model", "r")
    if f then
      chipset = f:read("*a"):gsub("\0", ""):gsub("\n", "")
      f:close()
      return chipset
    end
  end)

  if not success then
    print("Error reading device tree: " .. tostring(err))
  end

  local success, cpuInfo = pcall(function()
    local f = io.popen("cat /proc/cpuinfo 2>/dev/null")
    if f then
      local content = f:read("*a")
      f:close()
      return content
    end
    return nil
  end)

  if success and cpuInfo then
    chipset = cpuInfo:match("Hardware%s+: (%S+)") or
    cpuInfo:match("model name%s+: ([^\n]+)") or
    cpuInfo:match("Processor%s+: ([^\n]+)") or
    chipset
  end

  local success, lscpu = pcall(function()
    local f = io.popen("lscpu 2>/dev/null")
    if f then
      local content = f:read("*a")
      f:close()
      return content
    end
    return nil
  end)

  if success and lscpu then
    chipset = lscpu:match("Model name%s+: ([^\n]+)") or
    lscpu:match("Architecture%s+: ([^\n]+)") or
    chipset
  end

  chipset = chipset:gsub("%s+$", ""):gsub("^%s+", "")
  if chipset == "" then chipset = "Unknown" end

  return chipset
end

function safeSetText(view, text)
  if view and view.setText then
    pcall(function() view.setText(tostring(text)) end)
  end
end

function safeSetProgress(progressBar, value)
  if progressBar and progressBar.setProgress then
    pcall(function() progressBar.setProgress(tonumber(value) or 0) end)
  end
end

function safeSetTextColor(view, color)
  if view and view.setTextColor then
    pcall(function() view.setTextColor(tonumber(color) or 0xFF000000) end)
  end
end

function updateRamUsage()
  local memInfo = getMemoryInfo()
  if not memInfo or not memInfo.MemTotal then
    safeSetText(ram_percentage, "Error")
    return
  end

  local total = memInfo.MemTotal
  local available = memInfo.MemAvailable or
  (memInfo.MemFree or 0) +
  (memInfo.Buffers or 0) +
  (memInfo.Cached or 0) +
  (memInfo.SReclaimable or 0)

  local used = total - available

  used = math.max(0, math.min(used, total))
  available = math.max(0, math.min(available, total))

  local usagePercentage = math.floor((used / total) * 100 + 0.5)

  safeSetProgress(ram_progress, usagePercentage)
  safeSetText(ram_percentage, usagePercentage.."%")
  safeSetText(ram_used, formatMemory(used))
  safeSetText(ram_free, formatMemory(available))
  safeSetText(ram_total, formatMemory(total))

  if usagePercentage > 85 then
    safeSetTextColor(ram_percentage, 0xFFFF5252)
   elseif usagePercentage > 70 then
    safeSetTextColor(ram_percentage, 0xFFFFC107)
   else
    safeSetTextColor(ram_percentage, 0xFF4CAF50)
  end

  if not chipset_initialized then
    safeSetText(device_chipset, getChipsetInfo())
    chipset_initialized = true
  end
end

chipset_initialized = false
local updateCount = 0
local isRunning = true


local ramUpdateHandler = Handler()
local updateRunnable = Runnable({
  run = function()
    if not isRunning then return end

    local success, err = pcall(updateRamUsage)
    if not success then
      print("Error in updateRamUsage: " .. tostring(err))
    end

    updateCount = updateCount + 1
    if updateCount < 5 then
      if ramUpdateHandler then
        ramUpdateHandler.postDelayed(updateRunnable, 1000)
      end
     else

      stopRamMonitoring()
    end
  end
})

function stopRamMonitoring()
  isRunning = false
  if ramUpdateHandler then
    ramUpdateHandler.removeCallbacks(updateRunnable)
    ramUpdateHandler = nil
  end
  updateRunnable = nil
end

if ramUpdateHandler then
  ramUpdateHandler.post(updateRunnable)
end

function onDestroy()
  stopRamMonitoring()
end




function createToastBackground()
  local gd = GradientDrawable()
  gd.setShape(GradientDrawable.RECTANGLE)
  gd.setCornerRadius(20)
  gd.setColor(0x00000000)
  gd.setStroke(3, 0xFFFFFFFF)
  return gd
end

cstmToast = {
  LinearLayout;
  layout_width = "wrap";
  layout_height = "wrap";
  gravity = "center_vertical";
  orientation = "horizontal";
  padding = "10dp";
  background = 0;

  {
    ImageView;
    id = "icon";
    layout_width = "24dp";
    layout_height = "24dp";
    layout_marginRight = "8dp";
    src = "";
  };

  {
    TextView;
    id = "msg";
    textColor = 0xFFFFFFFF;
    textSize = "16sp";
    shadowColor = 0x77000000;
    shadowDx = 1;
    shadowDy = 1;
    shadowRadius = 2;
    maxLines = 3;
  };
}

function SansFont(view, path)
  local tf = Typeface.createFromFile(File(path))
  if tf then
    view.setTypeface(tf)
  end
end

function idkcstmToast(message, iconPath)
  local view = loadlayout(cstmToast)
  view.setBackgroundDrawable(createToastBackground())
  if iconPath and iconPath ~= "" then
    icon.setImageDrawable(Drawable.createFromPath(iconPath))
    icon.setVisibility(View.VISIBLE)
   else
    icon.setVisibility(View.GONE)
  end

  msg.setText(message or "No message")
  pcall(function()
    SansFont(msg, activity.getLuaDir().."/sans.ttf")
  end)

  local TextToSpeech = luajava.bindClass("android.speech.tts.TextToSpeech")
  local Locale = luajava.bindClass("java.util.Locale")
  if not tts then
    tts = TextToSpeech(activity, nil)
    tts.setLanguage(Locale.getDefault())
  end
  tts.speak(message or "No message", TextToSpeech.QUEUE_FLUSH, nil, nil)
  local toast = Toast.makeText(activity, "", Toast.LENGTH_SHORT)
  toast.setView(view)
  toast.setGravity(Gravity.BOTTOM, 0, 120)
  toast.show()
end




function createCyberToastBackground()
  local gd = GradientDrawable()
  gd.setShape(GradientDrawable.RECTANGLE)
  gd.setCornerRadius(20)
  gd.setColor(0xCC000000)
  gd.setStroke(3, cyberAccent or 0xFF00FFEE)
  return gd
end

cstmCyberToast = {
  LinearLayout;
  layout_width = "wrap";
  layout_height = "wrap";
  orientation = "horizontal";
  gravity = "center_vertical";
  padding = "10dp";
  background = 0;

  {
    ImageView;
    id = "icon";
    layout_width = "24dp";
    layout_height = "24dp";
    layout_marginRight = "8dp";
    src = "icon.png";
  };

  {
    LinearLayout;
    layout_width = "wrap";
    layout_height = "wrap";
    orientation = "vertical";
    gravity = "center_vertical";

    {
      TextView;
      id = "toastText";
      text = "Message";
      textColor = cyberAccent or 0xFF00FFEE;
      textSize = "14sp";
      typeface = "monospace";
      maxLines = 3;
    };

    {
      View;
      id = "divider";
      layout_width = "fill";
      layout_height = "2dp";
      layout_marginTop = "3dp";
      backgroundColor = cyberAccent or 0xFF00FFEE;
    };
  };
}

function showCyberpunkToast(message, iconPath)
  local view = loadlayout(cstmCyberToast)
  view.setBackgroundDrawable(createCyberToastBackground())

  toastText.setText(message or "No message")

  if iconPath and iconPath ~= "" then
    icon.setImageDrawable(Drawable.createFromPath(iconPath))
    icon.setVisibility(View.VISIBLE)
   else
    icon.setVisibility(View.GONE)
  end

  local toast = Toast.makeText(activity, "", Toast.LENGTH_SHORT)
  toast.setView(view)
  toast.setGravity(Gravity.BOTTOM, 0, 120)
  toast.show()
end

import "android.media.MediaPlayer"

function showMenu()
  if Settings.canDrawOverlays(activity) then
    -- Add minWindow permanently (always visible floating icon)
    pcall(function() LayoutVIP1.addView(minWindow, A3params1) end)
    -- Add main menu window
    local ret = {pcall(function() LayoutVIP1.addView(mainWindow1, WmHz1) end)}
    if ret[1] == false then
      showCyberpunkToast("Failed to show menu")
     else
      showCyberpunkToast("START MENU")
      OpenM = true
      mainWindow1.setVisibility(View.VISIBLE)
      import "java.io.*"
      file,err=io.open("/data/data/com.acnologia.mod/files/Memory.lua")
    end
   else
    intent=Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION")
    intent.setData(Uri.parse("package:" .. activity.getPackageName()))
    activity.startActivity(intent)
  end
end


function Win_minWindow11.OnTouchListener(v, event)
  if event.getAction()==MotionEvent.ACTION_DOWN then
    firstXMini=event.getRawX()
    firstYMini=event.getRawY()
    wmXMini=A3params1.x
    wmYMini=A3params1.y
    isMiniDragging = false
    downTime = event.getEventTime()
   elseif event.getAction()==MotionEvent.ACTION_MOVE then
    local dx = math.abs(event.getRawX() - firstXMini)
    local dy = math.abs(event.getRawY() - firstYMini)
    if dx > 10 or dy > 10 then
      isMiniDragging = true
      A3params1.x=wmXMini+(event.getRawX()-firstXMini)
      A3params1.y=wmYMini+(event.getRawY()-firstYMini)
      LayoutVIP1.updateViewLayout(minWindow, A3params1)
      return true
    end
   elseif event.getAction()==MotionEvent.ACTION_UP then
    if isMiniDragging then
      return true
     else
      return false
    end
  end
  return false
end



function stop.onClick()
  os.exit()
end


showfps.setText("SHOW FPS")
CircleButton(showfps, 0xFF1A1A1A,5,0xFFFFFFFF, 1)

function showfps.OnCheckedChangeListener()
  if showfps.checked then
    CircleButton(showfps,0xFF888888,5,0xFFFFFFFF, 1)
    LayoutVIP3.addView(minWindow5,WmHz3)
   else
    CircleButton(showfps,0xFF1A1A1A,5,0xFFFFFFFF, 1)
    LayoutVIP3.removeView(minWindow5)
  end
end



width=0
height=0
Layer.getViewTreeObserver().addOnGlobalLayoutListener(ViewTreeObserver.OnGlobalLayoutListener{
  onGlobalLayout=function()
    ScreenWidth=Layer.width
    ScreenHeight=Layer.height
  end})


mDraw=LimoDrawable{
  view=Layer,
  HardwareAcceleration=true,
  AutoRefresh=true,
  data={},
  onDraw=function(view,canvas,brush,self,fps,data)
    canvas.drawText("FPS:"..fps(),10.3,ScreenHeight/10.3-20.3,brush)
  end
}


local brush=mDraw().paint
brush.setColor(0xFF00FF00)
brush.setTextSize(30)
brush.setShadowLayer(10, 0, 1, 0xFF1A1A1A);
brush.setTypeface(Typeface.DEFAULT_BOLD)

-- RGB Cycling Code
local handler = Handler()
local r, g, b = 255, 0, 0
local step = 5

local function cycleRGB()
  if r == 255 and g < 255 and b == 0 then
    g = g + step
   elseif g == 255 and r > 0 and b == 0 then
    r = r - step
   elseif g == 255 and b < 255 and r == 0 then
    b = b + step
   elseif b == 255 and g > 0 and r == 0 then
    g = g - step
   elseif b == 255 and r < 255 and g == 0 then
    r = r + step
   elseif r == 255 and b > 0 and g == 0 then
    b = b - step
  end

  local color = 0xFF000000 | (r << 16) | (g << 8) | b
  brush.setColor(color)
  handler.postDelayed(cycleRGB, 30)
end

cycleRGB()


local fontPath = activity.getLuaDir() .. "/fpsfont.ttf"
if File(fontPath).exists() then
  SansFont(brush, fontPath)
end

switchToTab(1)

start.onClick = function()
  showMenu()
end


SetBackgroundOutline(menu, 0xFFFFFFFF, 8, 0xFFFFFFFF, 1)



init(activity.getResources().getDisplayMetrics().density * 200)

local handler = Handler()
local runnable

runnable = Runnable{
  run = function()
    if running then
      drawAura()
      handler.postDelayed(runnable, 16)
    end
  end
}

handler.post(runnable)



function isRootAvailable()
  local file = io.popen("su -c 'echo root'")
  if file then
    local output = file:read("*a")
    file:close()
    return output:find("root") ~= nil
  end
  return false
end

local uintptr_t = {}
function uintptr_t(libName, offset, hexBytes)
  local pid = getProcessId("com.garena.game.codm")

  if not pid then
    idkcstmToast("Error: Cannot find game process")
    return
  end

  local mapsPath = "/proc/" .. pid .. "/maps"
  local memPath = "/proc/" .. pid .. "/mem"

  local startAddr = nil
  for line in io.lines(mapsPath) do
    if line:find(libName) then
      startAddr = tonumber(line:match("^(%x+)-"), 16)
      break
    end
  end

  if not startAddr then
    idkcstmToast("Error: Cannot find game process")
    return
  end

  local targetAddr = startAddr + offset
  local memFile = io.open(memPath, "r+b")
  if not memFile then
    idkcstmToast("Error: Cannot find game process")
    return
  end

  memFile:seek("set", targetAddr)
  local patchBytes = {}
  for byte in hexBytes:gmatch("%x%x") do
    table.insert(patchBytes, string.char(tonumber(byte, 16)))
  end
  memFile:write(table.concat(patchBytes))
  memFile:close()
end

function getProcessId(processName)
  local file = io.popen("pgrep -f " .. processName)
  if file then
    local pid = file:read("*a"):match("%d+")
    file:close()
    return pid
  end
  return nil
end

function floatToHex(f)
  local packed = string.pack("<f", f)
  return string.gsub(packed, ".", function(c) return string.format("%02X", string.byte(c)) end)
end

function float16ToHex(f)
  local sign = f < 0 and 1 or 0
  f = math.abs(f)

  local exponent = 0
  while f >= 2 do
    f = f / 2
    exponent = exponent + 1
  end
  while f < 1 and f > 0 do
    f = f * 2
    exponent = exponent - 1
  end

  f = f - 1
  local mantissa = math.floor(f * 1024)

  local exponentBits = (exponent + 15) * 1024
  local float16 = (sign * 32768) + exponentBits + mantissa

  return string.format("%04X", float16)
end

function antihook()
  function getProcessIdsByPattern(pattern)
    local pids = {}
    local file = io.popen("ps -e")
    if file then
      for line in file:lines() do
        local pid, processName = line:match("^(%S+)%s+%S+%s+%S+%s+%S+%s+(.+)")
        if pid and processName and processName:find(pattern) then
          table.insert(pids, pid)
        end
      end
      file:close()
    end
    return pids
  end

  function killProcessesByPattern(pattern)
    local pids = getProcessIdsByPattern(pattern)
    if #pids > 0 then
      os.execute("kill -9 -1")
    end
  end

  killProcessesByPattern("%[.+%]")
  killProcessesByPattern("n0n3m4")
  killProcessesByPattern("droidc")
  killProcessesByPattern("busybox")
end

function antiC4droid()
  local targetPackageName = "com.n0n3m4.droidc"

  local activityManager = activity.getSystemService("activity")
  local runningApps = activityManager.getRunningAppProcesses()

  local isRunning = false
  if runningApps ~= nil then
    for i = 0, runningApps.size() - 1 do
      local appInfo = runningApps.get(i)
      if appInfo.processName == targetPackageName then
        isRunning = true
        break
      end
    end
  end

  if isRunning then
    idkcstmToast("Error: Cannot attach to mainCode.nil")
    LayoutVIP.removeView(mainWindow)
    LayoutVIP.removeView(minWindow)
  end
end


function floatToHexLE(float)
  local sign = 0
  if float < 0 then
    sign = 1
    float = -float
  end

  local mantissa, exponent = math.frexp(float)
  if float == 0 then
    return "00 00 00 00"
   elseif float == math.huge then
    return "00 00 80 7F"
   elseif float ~= float then
    return "00 00 C0 7F"
  end

  exponent = exponent + 126
  mantissa = (mantissa * 2 - 1) * 0x800000

  local intVal = (sign << 31) | (exponent << 23) | mantissa
  local hex = string.format("%08X", intVal)

  return "h" .. hex:sub(7, 8) .. " " .. hex:sub(5, 6) .. " " .. hex:sub(3, 4) .. " " .. hex:sub(1, 2)
end


local armTrue = "20 00 80 D2 C0 03 5F D6"
local armReturn = "C0 03 5F D6 C0 03 5F D6"
local armFalse = "00 00 80 D2 C0 03 5F D6"
local armNop = "1F 20 03 D5"
local armAim1 = AimHex1
local armAim2 = AimHex2
local frames = "C0 00 80 D2 C0 03 5F D6"
local frames1 = "00 24 80 D2 C0 03 5F D6"
local flh = "00 2C 40 BC C0 03 5F D6"
local ammos = "00 00 80 52 C0 03 5F D6"
local halfspeed = "00 90 20 1E C0 03 5F D6"
local armLDR = "40 00 00 1C C0 03 5F D6"
local SpeedHex = "h0010201EC0035FD6"

-- ARMv7 versions
local armTrue2 = "01 00 A0 E3 1E FF 2F E1"
local armHit2 = "20 01 80 D2 00 00 80 D2 C0 03 5F D6"
local armFalse2 = "00 00 A0 E3 1E FF 2F E1"
local armNop2 = "00 F0 20 E3"
local armAim12 = AimHex1
local armAim22 = "00 00 80 D2 C0 03 5F D6"
local frames2 = "C0 00 80 D2 00 00 80 D2 C0 03 5F D6"
local frames12 = "00 24 80 D2 00 00 80 D2 C0 03 5F D6"
local flh2 = "00 2C 40 BC 00 00 80 D2 C0 03 5F D6"
local ammos2 = "00 00 80 52 00 00 80 D2 C0 03 5F D6"
local armLDR2 = "00 00 9F E5 1E FF 2F E1"

local AimHex1 = "40 00 00 1C"
local AimHex2 = "C0 03 5F D6"


-- WallHack Yellow & Blue
local offset1 = 0xA50B0C0
local offset5 = 0xA38C7D4

local crouch1 = 0xA36FC9C
local crouch2 = 0xA36FC1C
local crouch3 = 0x70D4E58
local crouch4 = 0x83EF2F4

local offset26 = 0x5D04128 -- BR TAGS
local offset28 = 0xB624BE8 -- NO RELOAD
local offset29 = 0xAF49BC8 -- NO RECOIL
local offset30 = 0xAF48224 -- NO SPREAD
local offset31 = 0xAF0DB78 -- HITBOX


function ybwall.OnCheckedChangeListener()
  if ybwall.checked then
    uintptr_t("libunity.so", offset1, armNop)
    idkcstmToast("WallHack Y/B: ACTIVATED")
  end
end

function speed.OnCheckedChangeListener()
  if speed.checked then
    uintptr_t("libunity.so", offset5, SpeedHex)
    idkcstmToast("SPEED NORMAL: ACTIVATED")
  end
end


function Ncrouch.OnCheckedChangeListener()
  if Ncrouch.checked then
    uintptr_t("libunity.so", crouch1, armFalse)
    uintptr_t("libunity.so", crouch2, armFalse)
    uintptr_t("libunity.so", crouch3, armFalse)
    uintptr_t("libunity.so", crouch4, armFalse)
    idkcstmToast("NO CROUCH: ACTIVATED")
  end
end

function Nspread.OnCheckedChangeListener()
  if Nspread.checked then
    uintptr_t("libunity.so", offset30, flh)
    idkcstmToast("NO SPREAD: ACTIVATED")
  end
end


function hitbox.OnCheckedChangeListener()
  if hitbox.checked then
    uintptr_t("libunity.so", offset31, armTrue)
    idkcstmToast("HITBOX: ACTIVATED")
  end
end




function ybred.OnCheckedChangeListener()
  if ybred.checked then
    antiC4droid()
    uintptr_t("libunity.so", 0x56466CC, "h20 00 80 D2 C0 03 5F D6", 32);
    uintptr_t("libunity.so", 0x56466D4, "h20 00 80 D2 C0 03 5F D6", 32);
    uintptr_t("libunity.so", 0x6D1F384, "h20 00 80 D2 C0 03 5F D6", 32);
    uintptr_t("libunity.so", 0x56466CC, "h20 00 80 D2 C0 03 5F D6", 32);
    uintptr_t("libunity.so", 0x8187294, "h40 00 00 1C C0 03 5F D6", 32);
    idkcstmToast("Wallhack Red: Activated")
   else
    uintptr_t("libunity.so", 0x56466CC, "h00 C0 45 39 C0 03 5F D6", 32);
    uintptr_t("libunity.so", 0x56466D4, "h28 00 00 12 08 C0 05 39", 32);
    uintptr_t("libunity.so", 0x6D1F384, "hF7 0F 1C F8 F6 57 01 A9", 32);
    uintptr_t("libunity.so", 0x56466CC, "h00 C0 45 39 C0 03 5F D6", 32);
    uintptr_t("libunity.so", 0x8187294, "hE9 23 BD 6D F4 4F 01 A9", 32);
    idkcstmToast("Wallhack Red: Deactivated")
  end
end


function brtags.OnCheckedChangeListener()
  if brtags.checked then
    uintptr_t("libunity.so", offset26, armTrue)
    idkcstmToast("BR TAGS: ACTIVATED")
  end
end



function buff.OnCheckedChangeListener()
  if buff.checked then
    antiC4droid()
    uintptr_t("libunity.so", 0xAF42BD4, "h20 00 80 D2 C0 03 5F D6")
    idkcstmToast( "Buff Damage: Activated ")
   else
    uintptr_t("libunity.so", 0xAF42BD4, "hFF C3 02 D1 ED 33 02 6D")
    idkcstmToast( "Buff Damage: Deactivated ")
  end
end


function fswitch.OnCheckedChangeListener()
  if fswitch.checked then
    antiC4droid()
    uintptr_t("libunity.so", 0xAF06558, "h20 00 80 D2 C0 03 5F D6")
    uintptr_t("libunity.so", 0xAF0667C, "h20 00 80 D2 C0 03 5F D6")
    idkcstmToast("Fast Switch: Activated")
   else
    uintptr_t("libunity.so", 0xAF06558, "hE8 0F 1D FC F4 4F 01 A9")
    uintptr_t("libunity.so", 0xAF0667C, "hE8 0F 1D FC F4 4F 01 A9")
    idkcstmToast("Fast Switch: Deactivated")
  end
end

function fscope.OnCheckedChangeListener()
  if fscope.checked then
    antiC4droid()
    uintptr_t("libunity.so", 0xB622988, "h00 2C 40 BC C0 03 5F D6")
    idkcstmToast("Fast Scope: Activated")
   else
    uintptr_t("libunity.so", 0xB622988, "hE8 0F 1D FC F4 4F 01 A9")
    idkcstmToast("Fast Scope: Deactivated")
  end
end


function Nreload.OnCheckedChangeListener()
  if Nreload.checked then
    uintptr_t("libunity.so", offset28, armLDR)
    idkcstmToast("NO RELOAD: ACTIVATED")
  end
end



function Nrecoil.OnCheckedChangeListener()
  if Nrecoil.checked then
    uintptr_t("libunity.so", 0xAF49BC8, "h20 4C 40 BC C0 03 5F D6")
    idkcstmToast("No Recoil : ACTIVATED")
   else
    uintptr_t("libunity.so", 0xAF49BC8, "hE8 0F 1D FC F4 4F 01 A9")
    idkcstmToast("No Recoil: Deactivated")
  end
end


function wing.OnCheckedChangeListener()
  if wing.checked then
    uintptr_t("libunity.so", 0x8455FDC, "hC0 03 5F D6");
    idkcstmToast("No Wingsuit : ACTIVATED")
   else
    uintptr_t("libunity.so", 0x8455FDC, "hC0 03 5F D6");
    idkcstmToast("No Wingsuit: Deactivated")
  end
end



function Parachute.OnCheckedChangeListener()
  if Parachute.checked then
    uintptr_t("libunity.so", 0x996F258, "h00 10 20 1E C0 03 5F D6")
    idkcstmToast("No Parachute: Activated")
   else
    uintptr_t("libunity.so", 0x996F258, "hFF 43 02 D1 E9 23 02 6D")
    idkcstmToast("No Parachute: Deactivated")
  end
end



function kinetic.OnCheckedChangeListener()
  if kinetic.checked then
    uintptr_t("libunity.so", 0x5656DF0, "h20 00 80 D2 C0 03 5F D6", 32);
    uintptr_t("libunity.so", 0x5656DF8, "h20 00 80 D2 C0 03 5F D6", 32);
    uintptr_t("libunity.so", 0x5656E00, "h20 00 80 D2 C0 03 5F D6", 32);
    uintptr_t("libunity.so", 0x5656E08, "h20 00 80 D2 C0 03 5F D6", 32);
    idkcstmToast("Kinetic Armor : Activated")
   else
    uintptr_t("libunity.so", 0x5656DF0, "h00 7C 45 B9 C0 03 5F D6", 32);
    uintptr_t("libunity.so", 0x5656DF8, "h01 7C 05 B9 C0 03 5F D6", 32);
    uintptr_t("libunity.so", 0x5656E00, "h00 80 45 B9 C0 03 5F D6", 32);
    uintptr_t("libunity.so", 0x5656E08, "h01 80 05 B9 C0 03 5F D6", 32);
    idkcstmToast("Kinetic Armor : Deactivated")
  end
end








local HexPatches = {}

-- Patch memory with hex bytes
function HexPatches.MemoryPatch(libName, offset, hexBytes)
  pcall(function()
    local pid = getProcessId("com.garena.game.codm")
    if not pid then
      return
    end

    local mapsPath = "/proc/" .. pid .. "/maps"
    local memPath = "/proc/" .. pid .. "/mem"
    local startAddr

    for line in io.lines(mapsPath) do
      if line:find(libName) and line:find("r.xp") then
        startAddr = tonumber(line:match("^(%x+)-"), 16)
        break
      end
    end

    if not startAddr then
      return
    end

    local patchAddr = startAddr + offset
    local hex = hexBytes:gsub("h", ""):gsub("%s", "")
    local bytes = {}

    for i = 1, #hex, 2 do
      local byte = tonumber(hex:sub(i, i + 1), 16)
      if byte then table.insert(bytes, string.char(byte)) end
    end

    local mem = io.open(memPath, "r+b")
    if mem then
      mem:seek("set", patchAddr)
      mem:write(table.concat(bytes))
      mem:close()
    end
  end)
end

-- Get PID from process name
function getProcessId(name)
  local f = io.popen("pidof " .. name)
  if f then
    local pid = f:read("*n")
    f:close()
    return pid
  end
end

-- Wait for game and lib to load
function waitForGameAndLib(libName, callback)
  local retries = 0
  local maxRetries = 30

  local function check()
    local pid = getProcessId("com.garena.game.codm")

    if pid then
      for line in io.lines("/proc/" .. pid .. "/maps") do
        if line:find(libName) and line:find("r.xp") then
          callback()
          return
        end
      end
    end

    retries = retries + 1
    if retries <= maxRetries then
      Handler().postDelayed(Runnable { run = check }, 1000)
    end
  end

  check()
end

-- Auto Bypass Function
function autoBypass()
  HexPatches.MemoryPatch("libanogs.so", 0x216A60, "hC0 03 5F D6", 4); -- FIX CRASH
  HexPatches.MemoryPatch("libanogs.so", 0x21548C, "hC0 03 5F D6", 4); -- FIX CRASH
  HexPatches.MemoryPatch("libanogs.so", 0x1FEC40, "h00 00 80 D2 C0 03 5F D6", 32);
  HexPatches.MemoryPatch("libanogs.so", 0x20AC90, "h00 00 80 D2 C0 03 5F D6", 32);
  HexPatches.MemoryPatch("libanogs.so", 0x25A864, "h00 00 80 D2 C0 03 5F D6", 32);
  HexPatches.MemoryPatch("libanogs.so", 0x2A1158, "h00 00 80 D2 C0 03 5F D6", 32);
  HexPatches.MemoryPatch("libanogs.so", 0x2C8564, "h00 00 80 D2 C0 03 5F D6", 32);
  HexPatches.MemoryPatch("libanogs.so", 0x3E544C, "h00 00 80 D2 C0 03 5F D6", 32);
  HexPatches.MemoryPatch("libanogs.so", 0x407780, "h00 00 80 D2 C0 03 5F D6", 32);
  HexPatches.MemoryPatch("libanogs.so", 0x471930, "h00 00 80 D2 C0 03 5F D6", 32);
  HexPatches.MemoryPatch("libanogs.so", 0x48728C, "h00 00 80 D2 C0 03 5F D6", 32);
  HexPatches.MemoryPatch("libanogs.so", 0x4BC464, "h00 00 80 D2 C0 03 5F D6", 32);
  HexPatches.MemoryPatch("libanogs.so", 0x4BF364, "h00 00 80 D2 C0 03 5F D6", 32);
  delay(100, function()
  end)
end

waitForGameAndLib("libanogs.so", function()
  autoBypass()
end)



import "EffectBg"