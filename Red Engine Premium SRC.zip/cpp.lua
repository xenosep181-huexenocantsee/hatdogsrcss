function cppPatch(A0_37, A0_38)
  local path = activity.getLuaDir("SevSkin/" .. A0_37)
  os.execute("chmod 777 " .. path .. " " .. A0_38 .. " 2" .. " 3" .. " 4" .. " ‎ ")
  Runtime.getRuntime().exec(path .. " " .. A0_38 .. " 2" .. " 3" .. " 4" .. " ‎ ")
end



-- 🟣 Create background shape for Toast
function createToastBackground()
  local gd = GradientDrawable()
  gd.setShape(GradientDrawable.RECTANGLE)
  gd.setCornerRadius(20)
  gd.setColor(0x00000000) -- Inner dark translucent purple
  gd.setStroke(3, 0xFFFFFFFF) -- Purple border
  return gd
end

-- 🟣 Toast layout table (not directly using `createToastBackground` here, it will be applied later)
cstmToast = {
  LinearLayout;
  layout_width = "wrap";
  layout_height = "wrap";
  gravity = "center_vertical";
  orientation = "horizontal";
  padding = "10dp";
  background = 0; -- Placeholder, will assign via code

  {
    ImageView;
    id = "icon";
    layout_width = "24dp";
    layout_height = "24dp";
    layout_marginRight = "8dp";
    src = ""; -- to be set dynamically
  };

  {
    TextView;
    id = "msg";
    textColor = 0xFFFFFFFF;
    textSize = "16sp";
    shadowColor = 0x77000000;
    shadowDx = 1;
    shadowDy = 1;
    shadowRadius = 2;
    maxLines = 3;
  };
}

-- 🟣 Typeface loader (for custom fonts like sans.ttf)
function SansFont(view, path)
  local tf = Typeface.createFromFile(File(path))
  if tf then
    view.setTypeface(tf)
  end
end

-- 🟣 Custom Toast trigger function with voice-over
function idkcstmToast(message, iconPath)
  local view = loadlayout(cstmToast)
  view.setBackgroundDrawable(createToastBackground()) -- Apply drawable here

  if iconPath and iconPath ~= "" then
    icon.setImageDrawable(Drawable.createFromPath(iconPath))
    icon.setVisibility(View.VISIBLE)
   else
    icon.setVisibility(View.GONE)
  end

  msg.setText(message or "No message")
  pcall(function()
    SansFont(msg, activity.getLuaDir().."/sans.ttf")
  end)

  -- 🟣 Trigger Text-to-Speech (voice over)
  local TextToSpeech = luajava.bindClass("android.speech.tts.TextToSpeech")
  local Locale = luajava.bindClass("java.util.Locale")
  if not tts then
    tts = TextToSpeech(activity, nil)
    tts.setLanguage(Locale.getDefault())
  end
  tts.speak(message or "No message", TextToSpeech.QUEUE_FLUSH, nil, nil)

  local toast = Toast.makeText(activity, "", Toast.LENGTH_SHORT)
  toast.setView(view)
  toast.setGravity(Gravity.BOTTOM, 0, 120)
  toast.show()
end









function nyx.OnCheckedChangeListener()
  if nyx.checked then
    cppPatch("banner", "0781") -- NYX STARTSTRUCK
    sophia.setChecked(false)
    ghost.setChecked(false)
    siren.setChecked(false)
    templar.setChecked(false)
    spectre.setChecked(false)
  end
end




function sophia.OnCheckedChangeListener()
  if sophia.checked then
    cppPatch("banner", "0784") -- SOPHIA ERRANT KNIGHT
    nyx.setChecked(false)
    ghost.setChecked(false)
    siren.setChecked(false)
    templar.setChecked(false)
    spectre.setChecked(false)
  end
end


function ghost.OnCheckedChangeListener()
  if ghost.checked then
    cppPatch("angge", "1000") -- GHOST
    nyx.setChecked(false)
    sophia.setChecked(false)
    siren.setChecked(false)
    templar.setChecked(false)
    spectre.setChecked(false)
  end
end


function siren.OnCheckedChangeListener()
  if siren.checked then
    cppPatch("angge", "2000") -- SIREN
    nyx.setChecked(false)
    sophia.setChecked(false)
    ghost.setChecked(false)
    templar.setChecked(false)
    spectre.setChecked(false)
  end
end


function templar.OnCheckedChangeListener()
  if templar.checked then
    cppPatch("angge", "1500") -- TEMPLAR
    nyx.setChecked(false)
    sophia.setChecked(false)
    ghost.setChecked(false)
    siren.setChecked(false)
    spectre.setChecked(false)
  end
end


function spectre.OnCheckedChangeListener()
  if spectre.checked then
    cppPatch("angge", "2500") -- SPECTRE
    nyx.setChecked(false)
    sophia.setChecked(false)
    ghost.setChecked(false)
    siren.setChecked(false)
    templar.setChecked(false)
  end
end






function onButtonCheckedChange(checkbox, patchCode)
  checkbox.ButtonDrawable.setColorFilter(PorterDuffColorFilter(0xFFFFFFFF, PorterDuff.Mode.SRC_ATOP))
  checkbox.OnCheckedChangeListener = function()
    if checkbox.checked then
      cppPatch("thumbnail", patchCode)
      ak117.setChecked(false)
      bp50.setChecked(false)
      grau.setChecked(false)
      checkbox.setChecked(true)
    end
  end
end

onButtonCheckedChange(ak117, "078") -- AK117
onButtonCheckedChange(bp50, "081") -- BP50
onButtonCheckedChange(grau, "080") -- Grau





function tang.OnCheckedChangeListener()
  if tang.checked then
    cppPatch("ilove", "1000") -- TANGKNIFE
    idkcstmToast("TANG KNIFE: SUCCESS")
  end
end